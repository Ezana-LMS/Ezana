CREATE DATABASE IF NOT EXISTS `ezana_lms`;

USE `ezana_lms`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `ezanaLMS_AcademicSettings`;

CREATE TABLE `ezanaLMS_AcademicSettings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `current_academic_year` varchar(200) NOT NULL,
  `current_semester` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_AcademicSettings` VALUES (1,"Sep 2020 - Sep 2021 ","Jan - Apr ","","2021-01-04","2021-04-17"),
(2,"Sep 2020 - Sep 2021","May - Aug","Current","2021-05-03","2021-08-13"),
(3,"Sep 2020 - Sep 2021","Sep - Dec","","2021-09-13","2021-12-10");


DROP TABLE IF EXISTS `ezanaLMS_Admins`;

CREATE TABLE `ezanaLMS_Admins` (
  `id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `personal_email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `phone` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `national_id` varchar(200) NOT NULL,
  `date_employed` varchar(200) NOT NULL,
  `school` varchar(200) NOT NULL,
  `school_id` varchar(200) NOT NULL,
  `adr` varchar(200) NOT NULL,
  `previledge` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Admins` VALUES ("48d9affbf54f03b826112caf2aa31c83d57501fd18","Mart Mbithi","martinezmbithi@gmail.com","","45707dc9e751ded3ae2ea1f1eff4ce130c31a646","System Administrator","2021-06-10 15:58:57.682130",0704031263,"Male",123456,"","2021-06-10","School Of Computing Sciences","ba52fc866349d5af05addecba35600d0fd970ef7ba","<p>90126 Localhost<br></p>","","",""),
("632a8d58f7413d0c7bc964984dd5f0a98bbe22ba","Devlan Inc","martmbithi@protonmail.com","martmbithi@protonmail.com","812149be21df7c743b5ac042c56b400b023e012c","System Administrator","2021-06-22 13:06:12.020832",710010091,"Male",903838333,37690090,"2021-06-10","School Of Business And Management Studies","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","90127 Localhost","","",""),
("a69681bcf334ae130217fea4505fd3c994f5683f","Ezana LMS Sys Admin","sysadmin@ezana.org","sysadmin@ezana.org","adcd7048512e64b48da55b027577886ee5a36350","System Administrator","2021-06-22 12:19:07.703058","+90127690-90","Male","90-126","sysadmin@ezana.org","2021-04-07","School Of Computing Sciences","ba52fc866349d5af05addecba35600d0fd970ef7ba","129 - 90 127 Localhost","Edit And Delete","","");


DROP TABLE IF EXISTS `ezanaLMS_AssignmentsAttempts`;

CREATE TABLE `ezanaLMS_AssignmentsAttempts` (
  `id` varchar(200) NOT NULL,
  `assignment_id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `std_name` varchar(200) NOT NULL,
  `std_regno` varchar(200) NOT NULL,
  `attachments` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_AssignmentsAttempts` VALUES ("55d8e2595f4016bf7cff98cbe4fddab55bbb6720a0","d22abc9add171b7f9e1285e7b597ad01ff8a259e2d","Object Oriented Programming","BCS 1190","Mart Mbithi","EZANALMS002","16-Jun-2021-1623849291dummy.pdf","2021-06-16 16:14:51");


DROP TABLE IF EXISTS `ezanaLMS_BugReports`;

CREATE TABLE `ezanaLMS_BugReports` (
  `id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `bug_title` longtext NOT NULL,
  `bug_details` longblob NOT NULL,
  `severity` longtext NOT NULL,
  `date_reported` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_BugReports` VALUES ("65cf52f5f232e64165eadcd8c3c1d4924f264fe95d","martin","martdevelopers254@gmail.com","TDWXG74012","Laggy Loading ","<p>This system is loading slow<br></p>","High","2021-06-13 10:49:30","Pending Fix"),
("7c287a18fd59bfc9f525a467daa264a860aef8f0bf","martin","martdevelopers254@gmail.com","TDWXG74012","File Upload Issue","<p>Buggy file upload<br></p>","High","2021-06-21 13:44:22","Pending Fix");


DROP TABLE IF EXISTS `ezanaLMS_Calendar`;

CREATE TABLE `ezanaLMS_Calendar` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `academic_yr` varchar(200) NOT NULL,
  `semester_name` varchar(200) NOT NULL,
  `semester_start` varchar(200) NOT NULL,
  `semester_end` varchar(200) NOT NULL,
  `details` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Calendar` VALUES ("4cc386513d2274f6ae377d49f4880bdb06f68a3c30","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","Sep 2020 - Sep 2021","Jan - Apr","2021-06-23","2021-06-30","<p>Faculty open week<br></p>"),
("8bb2a506db08f0949628c058608fbdcfc9dda429f0","ba52fc866349d5af05addecba35600d0fd970ef7ba","Sep 2020 - Sep 2021","Jan - Apr","2021-06-21","2021-06-28","<p>Faculty Examination Week<br></p>"),
("ce9eaa19b408f9498a4a5333f1337e77bf354243e2","","Sep 2020 - Sep 2021","Jan - Apr","2021-06-22","2021-06-30","<p>Overall School Examination Weeks.<br></p>"),
("d2c4b201ecbf33627bfe50ad572a1d8994cdcc2dd4","ba52fc866349d5af05addecba35600d0fd970ef7ba","Sep 2020 - Sep 2021 ","Jan - Apr ","2021-04-12","2021-04-17","Faculty Exam week <br>");


DROP TABLE IF EXISTS `ezanaLMS_ClassRecordings`;

CREATE TABLE `ezanaLMS_ClassRecordings` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `clip_type` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `class_name` varchar(200) NOT NULL,
  `lecturer_name` varchar(200) NOT NULL,
  `external_link` varchar(200) NOT NULL,
  `video` longtext NOT NULL,
  `details` longblob NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_ClassRecordings` VALUES ("50ec338590398b824a9f66aa699b66570774bbc4c6","ba52fc866349d5af05addecba35600d0fd970ef7ba","Link","69488c64666d64defa40625c14e92323c27d7fa0ed","Quantum Computing 101","Mart Developers","https://www.youtube.com/watch?v=45Q4Zk3CN8k","","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. In tellus integer \r\nfeugiat scelerisque varius morbi enim nunc. Non consectetur a erat nam. \r\nEnim nunc faucibus a pellentesque sit amet porttitor eget. Eget nulla \r\nfacilisi etiam dignissim diam. Aliquam sem et tortor consequat id porta \r\nnibh venenatis. Morbi quis commodo odio aenean. Faucibus turpis in eu mi\r\n bibendum neque egestas congue. In est ante in nibh mauris cursus. \r\nSemper risus in hendrerit gravida rutrum. Eros donec ac odio tempor \r\norci. Ut pharetra sit amet aliquam. Accumsan lacus vel facilisis \r\nvolutpat est. Mattis enim ut tellus elementum. Nisl condimentum id \r\nvenenatis a condimentum vitae sapien pellentesque habitant. Tempus quam \r\npellentesque nec nam aliquam sem et tortor consequat. Amet aliquam id \r\ndiam maecenas ultricies mi eget. Risus at ultrices mi tempus imperdiet \r\nnulla. Interdum consectetur libero id faucibus nisl tincidunt eget \r\nnullam. At erat pellentesque adipiscing commodo elit at imperdiet dui.</p>\r\n<p>Neque aliquam vestibulum morbi blandit cursus. Cras ornare arcu dui \r\nvivamus. Risus at ultrices mi tempus imperdiet nulla. Morbi non arcu \r\nrisus quis varius quam quisque id diam. Hac habitasse platea dictumst \r\nquisque sagittis purus. Nisl vel pretium lectus quam id leo in vitae \r\nturpis. Neque volutpat ac tincidunt vitae semper. Morbi tincidunt ornare\r\n massa eget egestas purus. Eu mi bibendum neque egestas congue quisque. \r\nNisi est sit amet facilisis magna etiam tempor orci eu. Lectus mauris \r\nultrices eros in cursus.</p></div>","25 Jun 2021",""),
("63b98109bc7cc4a214943633147ca14bda00a81616","ba52fc866349d5af05addecba35600d0fd970ef7ba","Clip","69488c64666d64defa40625c14e92323c27d7fa0ed","Quantum Computing 101","Mart Developers","","1624624910Earth.mp4","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. In tellus integer \r\nfeugiat scelerisque varius morbi enim nunc. Non consectetur a erat nam. \r\nEnim nunc faucibus a pellentesque sit amet porttitor eget. Eget nulla \r\nfacilisi etiam dignissim diam. Aliquam sem et tortor consequat id porta \r\nnibh venenatis. Morbi quis commodo odio aenean. Faucibus turpis in eu mi\r\n bibendum neque egestas congue. In est ante in nibh mauris cursus. \r\nSemper risus in hendrerit gravida rutrum. Eros donec ac odio tempor \r\norci. Ut pharetra sit amet aliquam. Accumsan lacus vel facilisis \r\nvolutpat est. Mattis enim ut tellus elementum. Nisl condimentum id \r\nvenenatis a condimentum vitae sapien pellentesque habitant. Tempus quam \r\npellentesque nec nam aliquam sem et tortor consequat. Amet aliquam id \r\ndiam maecenas ultricies mi eget. Risus at ultrices mi tempus imperdiet \r\nnulla. Interdum consectetur libero id faucibus nisl tincidunt eget \r\nnullam. At erat pellentesque adipiscing commodo elit at imperdiet dui.</p>\r\n<p>Neque aliquam vestibulum morbi blandit cursus. Cras ornare arcu dui \r\nvivamus. Risus at ultrices mi tempus imperdiet nulla. Morbi non arcu \r\nrisus quis varius quam quisque id diam. Hac habitasse platea dictumst \r\nquisque sagittis purus. Nisl vel pretium lectus quam id leo in vitae \r\nturpis. Neque volutpat ac tincidunt vitae semper. Morbi tincidunt ornare\r\n massa eget egestas purus. Eu mi bibendum neque egestas congue quisque. \r\nNisi est sit amet facilisis magna etiam tempor orci eu. Lectus mauris \r\nultrices eros in cursus.</p></div>","25 Jun 2021","");


DROP TABLE IF EXISTS `ezanaLMS_CourseDirectories`;

CREATE TABLE `ezanaLMS_CourseDirectories` (
  `id` varchar(200) NOT NULL,
  `course_code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_materials` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_CourseMemo`;

CREATE TABLE `ezanaLMS_CourseMemo` (
  `id` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_memo` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `faculty_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_CourseMemo` VALUES ("78e32cae718cc4fd7cf942f434a04511f6e729217b","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","Bachelors In Computational Mathematics","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Porta nibh venenatis\r\n cras sed. A erat nam at lectus urna duis convallis convallis tellus. \r\nCommodo sed egestas egestas fringilla phasellus faucibus scelerisque. \r\nCursus eget nunc scelerisque viverra mauris in aliquam sem fringilla. \r\nLacinia quis vel eros donec ac odio. Vestibulum lectus mauris ultrices \r\neros in. Quis varius quam quisque id diam vel quam elementum. Consequat \r\ninterdum varius sit amet mattis vulputate enim nulla aliquet. Odio eu \r\nfeugiat pretium nibh ipsum consequat nisl vel pretium. Neque vitae \r\ntempus quam pellentesque nec nam aliquam sem. Amet purus gravida quis \r\nblandit turpis cursus in. Sit amet consectetur adipiscing elit ut \r\naliquam purus sit amet. Tempor orci dapibus ultrices in iaculis nunc \r\nsed. Ac auctor augue mauris augue neque gravida in fermentum. Mollis \r\nnunc sed id semper risus in hendrerit gravida.</p>\r\n<p>Sem nulla pharetra diam sit. Pellentesque nec nam aliquam sem et \r\ntortor. Nisl vel pretium lectus quam id leo in. Varius morbi enim nunc \r\nfaucibus a pellentesque sit. In tellus integer feugiat scelerisque \r\nvarius morbi enim nunc faucibus. Viverra aliquet eget sit amet tellus \r\ncras adipiscing. Quam lacus suspendisse faucibus interdum posuere lorem.\r\n Dolor purus non enim praesent elementum facilisis leo vel. Nunc \r\nlobortis mattis aliquam faucibus purus in massa tempor. Fames ac turpis \r\negestas integer eget aliquet nibh praesent tristique.</p></div>","1624445314dummy.pdf","Ezana LMS Sys Admin","2021-06-23 13:48:34","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("ec6f6febea3e96d38517e393e2841b0c9fa7902d41","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","Bachelors In Computational Mathematics","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Porta nibh venenatis\r\n cras sed. A erat nam at lectus urna duis convallis convallis tellus. \r\nCommodo sed egestas egestas fringilla phasellus faucibus scelerisque. \r\nCursus eget nunc scelerisque viverra mauris in aliquam sem fringilla. \r\nLacinia quis vel eros donec ac odio. Vestibulum lectus mauris ultrices \r\neros in. Quis varius quam quisque id diam vel quam elementum. Consequat \r\ninterdum varius sit amet mattis vulputate enim nulla aliquet. Odio eu \r\nfeugiat pretium nibh ipsum consequat nisl vel pretium. Neque vitae \r\ntempus quam pellentesque nec nam aliquam sem. Amet purus gravida quis \r\nblandit turpis cursus in. Sit amet consectetur adipiscing elit ut \r\naliquam purus sit amet. Tempor orci dapibus ultrices in iaculis nunc \r\nsed. Ac auctor augue mauris augue neque gravida in fermentum. Mollis \r\nnunc sed id semper risus in hendrerit gravida.</p>\r\n<p>Sem nulla pharetra diam sit. Pellentesque nec nam aliquam sem et \r\ntortor. Nisl vel pretium lectus quam id leo in. Varius morbi enim nunc \r\nfaucibus a pellentesque sit. In tellus integer feugiat scelerisque \r\nvarius morbi enim nunc faucibus. Viverra aliquet eget sit amet tellus \r\ncras adipiscing. Quam lacus suspendisse faucibus interdum posuere lorem.\r\n Dolor purus non enim praesent elementum facilisis leo vel. Nunc \r\nlobortis mattis aliquam faucibus purus in massa tempor. Fames ac turpis \r\negestas integer eget aliquet nibh praesent tristique.</p></div>","1624445013dummy.pdf","Ezana LMS Sys Admin","2021-06-23 13:43:33","ba52fc866349d5af05addecba35600d0fd970ef7ba");


DROP TABLE IF EXISTS `ezanaLMS_Courses`;

CREATE TABLE `ezanaLMS_Courses` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `faculty_name` varchar(200) NOT NULL,
  `department_id` varchar(200) NOT NULL,
  `department_name` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `hod` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Courses` VALUES ("02abafc898bc2b993cc646fff7fd94078442f33c1c","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","91fb1b9f83b9aa2fe398e4dd6e6a449490e89659e2","Quantum Computing","CIQC","Certificate In Quantum Computing","Mart Developers","martdevelopers254@gmail.com","<p>Certificate In Quantum ComputingCertificate In Quantum ComputingCertificate In Quantum ComputingCertificate In Quantum ComputingCertificate In Quantum ComputingCertificate In Quantum ComputingCertificate In Quantum ComputingCertificate I<br></p>"),
("49943644fdc0a65810f0c2f58de2ec69d0c8a9d307","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","e8ba39cec3ef9f1842be2b46f65aa7fca0737e674e","Computer Science","BCS","Bachelors In Computer Science","Mr James Holden","jamesholden@bcs.ezana.org","<p>Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. </p><p><br></p><p>Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. </p>"),
("5e4b1611c4e4f0a08fdb5836c36df64e66cc1590de","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","34f3325cdbc195b70b5956f8977b7ec7e9f5f21119","Small Business Enterprises Management","QCISN23618","Procurement","","","<p><b>Procurement</b> is the process of finding and agreeing to terms, and acquiring <a href=\"https://en.wikipedia.org/wiki/Goods\" title=\"Goods\">goods</a>, <a href=\"https://en.wikipedia.org/wiki/Service_(economics)\" title=\"Service (economics)\">services</a>, or works from an external source, often via a tendering or competitive <a href=\"https://en.wikipedia.org/wiki/Bidding\" title=\"Bidding\">bidding</a> process.<sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-1\">[1]</a></sup>\r\n</p><p>Procurement generally involves making buying decisions under conditions of <a href=\"https://en.wikipedia.org/wiki/Scarcity\" title=\"Scarcity\">scarcity</a>. If sound data is available, it is good practice to make use of economic analysis methods such as <a href=\"https://en.wikipedia.org/wiki/Cost-benefit_analysis\" class=\"mw-redirect\" title=\"Cost-benefit analysis\">cost-benefit analysis</a> or <a href=\"https://en.wikipedia.org/wiki/Cost-utility_analysis\" class=\"mw-redirect\" title=\"Cost-utility analysis\">cost-utility analysis</a>.\r\n</p><p>Procurement as an organizational process is intended to ensure \r\nthat the buyer receives goods, services, or works at the best possible \r\nprice when aspects such as quality, quantity, time, and location are \r\ncompared.<sup id=\"cite_ref-2\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-2\">[2]</a></sup>\r\n Corporations and public bodies often define processes intended to \r\npromote fair and open competition for their business while minimizing \r\nrisks such as exposure to fraud and collusion.\r\n</p><p>Almost all purchasing decisions include factors such as delivery and handling, <a href=\"https://en.wikipedia.org/wiki/Marginal_benefit\" class=\"mw-redirect\" title=\"Marginal benefit\">marginal benefit</a>, and <a href=\"https://en.wikipedia.org/wiki/Volatility_(finance)\" title=\"Volatility (finance)\"> price fluctuations</a>. Organisations which have adopted a <a href=\"https://en.wikipedia.org/wiki/Corporate_social_responsibility\" title=\"Corporate social responsibility\">corporate social responsibility</a>\r\n perspective are also likely to require their purchasing activity to \r\ntake wider societal and ethical considerations into account.<sup id=\"cite_ref-3\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-3\">[3]</a></sup>\r\n</p>"),
("78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","801b96f782310aa15ae942e6e6dd6fea0ec8fc0f57","Computational Science And Mathematics","BCM","Bachelors In Computational Mathematics","Mart Developers","martdevelopers254@gmail.com","<p>Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.</p><p><br></p><p>[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. </p>"),
("83dccbf9942bbada9ce4696f6a075e51e98b4de662","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","801b96f782310aa15ae942e6e6dd6fea0ec8fc0f57","Computational Science And Mathematics","DICM","Diploma In Computational Mathematics","Mrs Jane F Doe","janedoe@dicm.ezana.org","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. "),
("9bd615c255bc533378e946171d9b8fa61980605a70","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","e8ba39cec3ef9f1842be2b46f65aa7fca0737e674e","Computer Science","DICS","Diploma In Computer Science","Mrs Jane F Doe","janefdoe@dics.ezana.org","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. "),
("c9ecf35a11caec7d8269b065ce973bbed588603797","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","80cd6743cfce978a5a76b065df0b22c1c377eba9d6","Procurement Studies","WTHJB17603","Fundermentals Of Procurement","Mart Developers","martdevelopers254@gmail.com","<p>\r\nFormalized acquisition of goods and services has its roots in <a href=\"https://en.wikipedia.org/wiki/Military_logistics\" title=\"Military logistics\">military logistics</a>,\r\n where the ancient practice of foraging and looting was taken up by \r\nprofessional quartermasters, a term which dates from the 17th Century. \r\nThe first written records of what would be recognized now as the \r\npurchasing department of an industrial operation is in the railway \r\ncompanies of the 19th Century. </p><blockquote class=\"templatequote\"><p>\"The\r\n intelligence and fidelity exercised in the purchase, care and use of \r\nrailway supplies influences directly the cost of construction and \r\noperating and affect the reputations of officers and the profits of \r\nowners.\"<sup id=\"cite_ref-4\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-4\">[4]</a></sup></p></blockquote><p> An early reference book from 1922 explains that\r\n</p><blockquote class=\"templatequote\"><p>\"The modern purchasing agent is a more important man [<i><a href=\"https://en.wikipedia.org/wiki/Sic\" title=\"Sic\">sic</a></i>]\r\n by far than he was in older days when purchasing agents were likely to \r\nbe rubber stamps or bargainers for an extra penny. A Purchasing agent of\r\n the modern breed is a creative thinker and planner and now regards his \r\nwork as a profession.\"<sup id=\"cite_ref-5\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-5\">[5]</a></sup></p></blockquote>"),
("e26fd8b2c07802b779f38653384c3bcc34af85f33c","ba52fc866349d5af05addecba35600d0fd970ef7ba","Computer Science","7176b7a645b0bade3643d21c4966575a5391812df9","Computational Information And Informatics Sciences","CLYPE39812","Informatic Sciences","MartinMbithi","martinezmbithi@gmail.com","<p><b>Informatics</b> is the study of computational systems, especially those for data storage and retrieval.<sup id=\"cite_ref-:1_1-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Informatics#cite_note-:1-1\">[1]</a></sup><sup id=\"cite_ref-2\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Informatics#cite_note-2\">[2]</a></sup> According to ACM <i>Europe and</i> <i><a href=\"https://en.wikipedia.org/wiki/Informatics_Europe\" title=\"Informatics Europe\">Informatics Europe</a></i>, informatics is synonymous with <a href=\"https://en.wikipedia.org/wiki/Computer_science\" title=\"Computer science\">computer science</a> and <a href=\"https://en.wikipedia.org/wiki/Computing\" title=\"Computing\">computing</a> as a profession,<sup id=\"cite_ref-:2_3-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Informatics#cite_note-:2-3\">[3]</a></sup> in which the central notion is <a href=\"https://en.wikipedia.org/wiki/Information_processing\" title=\"Information processing\">transformation of information</a>.<sup id=\"cite_ref-:1_1-1\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Informatics#cite_note-:1-1\">[1]</a></sup><sup id=\"cite_ref-4\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Informatics#cite_note-4\">[4]</a></sup> In other countries, the term \"informatics\" is used with a different meaning in the context of <a href=\"https://en.wikipedia.org/wiki/Library_science\" title=\"Library science\">library science</a>.\r\n</p>");


DROP TABLE IF EXISTS `ezanaLMS_DepartmentalMemos`;

CREATE TABLE `ezanaLMS_DepartmentalMemos` (
  `id` varchar(200) NOT NULL,
  `department_id` varchar(200) NOT NULL,
  `department_name` varchar(200) NOT NULL,
  `memo_title` longtext NOT NULL,
  `departmental_memo` longblob NOT NULL,
  `target_audience` varchar(200) NOT NULL,
  `attachments` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `update_status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_DepartmentalMemos` VALUES ("33abf9d27a19dcf6892130d51220c5615d8dbf3dda","34f3325cdbc195b70b5956f8977b7ec7e9f5f21119","Small Business Enterprises Management","Quality Assurance Update","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Proin sagittis nisl \r\nrhoncus mattis rhoncus urna neque. Lobortis feugiat vivamus at augue. \r\nSit amet venenatis urna cursus eget nunc scelerisque viverra. Mus mauris\r\n vitae ultricies leo integer. Adipiscing enim eu turpis egestas pretium \r\naenean pharetra magna ac. Fermentum et sollicitudin ac orci phasellus. \r\nVulputate mi sit amet mauris commodo quis imperdiet massa. Pulvinar \r\nsapien et ligula ullamcorper malesuada proin libero nunc. Nunc vel risus\r\n commodo viverra maecenas accumsan lacus vel. Nulla pellentesque \r\ndignissim enim sit.</p>\r\n<p>Sollicitudin ac orci phasellus egestas. Nunc eget lorem dolor sed. \r\nEnim nunc faucibus a pellentesque. Elementum integer enim neque volutpat\r\n ac tincidunt vitae. Tortor at auctor urna nunc id cursus metus. Enim ut\r\n tellus elementum sagittis vitae et leo. Enim diam vulputate ut pharetra\r\n sit amet aliquam. Amet risus nullam eget felis eget. Arcu cursus \r\neuismod quis viverra nibh cras. Orci dapibus ultrices in iaculis nunc \r\nsed augue lacus. Sem et tortor consequat id porta nibh venenatis cras. \r\nNunc vel risus commodo viverra maecenas accumsan lacus. Elit duis \r\ntristique sollicitudin nibh.</p></div>","Students","1624438597dummy.pdf","2021-06-23 11:56:37","Ezana LMS Sys Admin","","Memo","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","Recently Updated"),
("4b36fe0dfc8bd44925778c7021014f15220a66b237","34f3325cdbc195b70b5956f8977b7ec7e9f5f21119","Small Business Enterprises Management","","","","1624367124dummy.pdf","2021-06-22 16:05:24","Devlan Inc","","Departmental Document","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc",""),
("8479b3d73b1e9f8afbd4b6ab5c0bb1d217e3988afd","83f09900a406e3f0619153a17c5b077bf8689acaea","Logistics","","","","1624366943dummy.pdf","2021-06-22 16:02:23","Devlan Inc","","Memo","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc",""),
("93c29388ccf2e151e7f725c7d3d73d06aa1f3cfb86","0946e40db117c701a20eff2dbbe438088c4a710958","STEM","Examinations Date Update","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Proin sagittis nisl \r\nrhoncus mattis rhoncus urna neque. Lobortis feugiat vivamus at augue. \r\nSit amet venenatis urna cursus eget nunc scelerisque viverra. Mus mauris\r\n vitae ultricies leo integer. Adipiscing enim eu turpis egestas pretium \r\naenean pharetra magna ac. Fermentum et sollicitudin ac orci phasellus. \r\nVulputate mi sit amet mauris commodo quis imperdiet massa. Pulvinar \r\nsapien et ligula ullamcorper malesuada proin libero nunc. Nunc vel risus\r\n commodo viverra maecenas accumsan lacus vel. Nulla pellentesque \r\ndignissim enim sit.</p>\r\n</div>","Students","1624439164dummy.pdf","2021-06-23 12:06:04","Ezana LMS Sys Admin","","Memo","ba52fc866349d5af05addecba35600d0fd970ef7ba",""),
("c0c17ed5669a6fdadf0de75d3302a6c7d7e8ce88d0","0946e40db117c701a20eff2dbbe438088c4a710958","STEM","","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Proin sagittis nisl \r\nrhoncus mattis rhoncus urna neque. Lobortis feugiat vivamus at augue. \r\nSit amet venenatis urna cursus eget nunc scelerisque viverra. Mus mauris\r\n vitae ultricies leo integer. Adipiscing enim eu turpis egestas pretium \r\naenean pharetra magna ac. Fermentum et sollicitudin ac orci phasellus. \r\nVulputate mi sit amet mauris commodo quis imperdiet massa. Pulvinar \r\nsapien et ligula ullamcorper malesuada proin libero nunc. Nunc vel risus\r\n commodo viverra maecenas accumsan lacus vel. Nulla pellentesque \r\ndignissim enim sit.</p><br></div>","","","2021-06-23 12:04:11","","","Announcement","ba52fc866349d5af05addecba35600d0fd970ef7ba",""),
("cce40a7c90fb985c1b32313bfe1a0fa1dc75781b3a","34f3325cdbc195b70b5956f8977b7ec7e9f5f21119","Small Business Enterprises Management","","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Proin sagittis nisl \r\nrhoncus mattis rhoncus urna neque. Lobortis feugiat vivamus at augue. \r\nSit amet venenatis urna cursus eget nunc scelerisque viverra. Mus mauris\r\n vitae ultricies leo integer. Adipiscing enim eu turpis egestas pretium \r\naenean pharetra magna ac. Fermentum et sollicitudin ac orci phasellus. \r\nVulputate mi sit amet mauris commodo quis imperdiet massa. Pulvinar \r\nsapien et ligula ullamcorper malesuada proin libero nunc. Nunc vel risus\r\n commodo viverra maecenas accumsan lacus vel. Nulla pellentesque \r\ndignissim enim sit.</p></div>","","","2021-06-23 11:15:53","","","Announcement","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc",""),
("d3c577e9fd5161d6709aa4365f1924ada07a0375d4","0946e40db117c701a20eff2dbbe438088c4a710958","STEM","","","","1624439195dummy.pdf","2021-06-23 12:06:35","Ezana LMS Sys Admin","","Departmental Document","ba52fc866349d5af05addecba35600d0fd970ef7ba","");


DROP TABLE IF EXISTS `ezanaLMS_Departments`;

CREATE TABLE `ezanaLMS_Departments` (
  `id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `faculty_name` varchar(200) NOT NULL,
  `hod` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Departments` VALUES ("0946e40db117c701a20eff2dbbe438088c4a710958","TLSMX70269","STEM","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","Mr Mart Devopers","","<p>STEM&nbsp; - Science, technology engineering and Mathematics.<br></p>","21 Apr 2021"),
("34f3325cdbc195b70b5956f8977b7ec7e9f5f21119","QSHDE30579","Small Business Enterprises Management","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","Mart Developers","martdevelopers254@gmail.com","<p>Small Business Enterprises Management is a department in School of business management.<br></p>","21 Apr 2021"),
("7176b7a645b0bade3643d21c4966575a5391812df9","JUVDS67845","Computational Information And Informatics Sciences","ba52fc866349d5af05addecba35600d0fd970ef7ba","Computer Science","Mart","martmbithi@protonmail.com","<p><span style=\"font-family: &quot;Source Sans Pro&quot;;\">Information theory, closely related to </span><a href=\"https://en.wikipedia.org/wiki/Probability\" title=\"Probability\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">probability</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\"> and </span><a href=\"https://en.wikipedia.org/wiki/Statistics\" title=\"Statistics\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">statistics</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\">, is related to the quantification of information. This was developed by </span><a href=\"https://en.wikipedia.org/wiki/Claude_Shannon\" title=\"Claude Shannon\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">Claude Shannon</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\"> to find fundamental limits on </span><a href=\"https://en.wikipedia.org/wiki/Signal_processing\" title=\"Signal processing\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">signal processing</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\"> operations such as compressing data and on reliably storing and communicating data.</span><sup id=\"cite_ref-47\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Computer_science#cite_note-47\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">[44]</span></a></sup><span style=\"font-family: &quot;Source Sans Pro&quot;;\">\r\nCoding theory is the study of the properties of </span><a href=\"https://en.wikipedia.org/wiki/Code\" title=\"\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">codes</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\"> (systems for converting information from one form to another) and their fitness for a specific application. Codes are used for </span><a href=\"https://en.wikipedia.org/wiki/Data_compression\" title=\"Data compression\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">data compression</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\">, </span><a href=\"https://en.wikipedia.org/wiki/Cryptography\" title=\"Cryptography\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">cryptography</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\">, </span><a href=\"https://en.wikipedia.org/wiki/Error_detection_and_correction\" title=\"Linear network coding\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">error detection and correction</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\">, and more recently also for </span><a href=\"https://en.wikipedia.org/wiki/Linear_network_coding\" title=\"\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">network coding</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\">. Codes are studied for the purpose of designing efficient and reliable </span><a href=\"https://en.wikipedia.org/wiki/Data_transmission\" class=\"mw-redirect\" title=\"Data transmission\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">data transmission</span></a><span style=\"font-family: &quot;Source Sans Pro&quot;;\"> methods.\r\n</span><sup id=\"cite_ref-48\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Computer_science#cite_note-48\"><span style=\"font-family: &quot;Source Sans Pro&quot;;\">[45]</span></a></sup></p>","21 Jun 2021"),
("801b96f782310aa15ae942e6e6dd6fea0ec8fc0f57","MRXQP81349","Computational Science And Mathematics","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","MartinMbithi","martinezmbithi@gmail.com","<p>Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer </p><p>components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. </p>","29 Mar 2021"),
("80cd6743cfce978a5a76b065df0b22c1c377eba9d6","WKNTR95781","Procurement Studies","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","Mart Developers","martdevelopers254@gmail.com","<p><b>Procurement</b> is the process of finding and agreeing to terms, and acquiring <a href=\"https://en.wikipedia.org/wiki/Goods\" title=\"Goods\">goods</a>, <a href=\"https://en.wikipedia.org/wiki/Service_(economics)\" title=\"Service (economics)\">services</a>, or works from an external source, often via a tendering or competitive <a href=\"https://en.wikipedia.org/wiki/Bidding\" title=\"Bidding\">bidding</a> process.<sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-1\">[1]</a></sup>\r\n</p><p>Procurement generally involves making buying decisions under conditions of <a href=\"https://en.wikipedia.org/wiki/Scarcity\" title=\"Scarcity\">scarcity</a>. If sound data is available, it is good practice to make use of economic analysis methods such as <a href=\"https://en.wikipedia.org/wiki/Cost-benefit_analysis\" class=\"mw-redirect\" title=\"Cost-benefit analysis\">cost-benefit analysis</a> or <a href=\"https://en.wikipedia.org/wiki/Cost-utility_analysis\" class=\"mw-redirect\" title=\"Cost-utility analysis\">cost-utility analysis</a>.\r\n</p><p>Procurement as an organizational process is intended to ensure \r\nthat the buyer receives goods, services, or works at the best possible \r\nprice when aspects such as quality, quantity, time, and location are \r\ncompared.<sup id=\"cite_ref-2\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-2\">[2]</a></sup>\r\n Corporations and public bodies often define processes intended to \r\npromote fair and open competition for their business while minimizing \r\nrisks such as exposure to fraud and collusion.\r\n</p><p>Almost all purchasing decisions include factors such as delivery and handling, <a href=\"https://en.wikipedia.org/wiki/Marginal_benefit\" class=\"mw-redirect\" title=\"Marginal benefit\">marginal benefit</a>, and <a href=\"https://en.wikipedia.org/wiki/Volatility_(finance)\" title=\"Volatility (finance)\"> price fluctuations</a>. Organisations which have adopted a <a href=\"https://en.wikipedia.org/wiki/Corporate_social_responsibility\" title=\"Corporate social responsibility\">corporate social responsibility</a>\r\n perspective are also likely to require their purchasing activity to \r\ntake wider societal and ethical considerations into account.<sup id=\"cite_ref-3\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Procurement#cite_note-3\">[3]</a></sup>\r\n</p>",""),
("83f09900a406e3f0619153a17c5b077bf8689acaea","ZJMYS57903","Logistics","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","Mrs JanetDoe","","<p>Logistics is a department on School of computing sciences.<br></p>","21 Apr 2021"),
("91fb1b9f83b9aa2fe398e4dd6e6a449490e89659e2","TYMOJ19840","Quantum Computing","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","Mr James Doe","","<p>Quantum Computing is another department in school of computing sciences.<br></p>","21 Apr 2021"),
("d8c78d5696f4d5460d0fdf350ecdf05e3b6d6170b2","ZCFDB50296","Computer Enginerring","ba52fc866349d5af05addecba35600d0fd970ef7ba","Computer Science","Lecturer 0010025","martinezmbithi@gmail.com","<p>Just another department<br></p>","17 Jun 2021"),
("e8ba39cec3ef9f1842be2b46f65aa7fca0737e674e","RUWKI08562","Computer Science","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","Mart Developers","martdevelopers254@gmail.com","<p><span style=\"font-family: &quot;Courier New&quot;;\" courier=\"\" new\";\"=\"\">Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4]</span></p><p><span style=\"font-family: &quot;Courier New&quot;;\" courier=\"\" new\";\"=\"\"> Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. </span></p>","29 Mar 2021");


DROP TABLE IF EXISTS `ezanaLMS_Enrollments`;

CREATE TABLE `ezanaLMS_Enrollments` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `student_adm` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `semester_enrolled` varchar(200) NOT NULL,
  `course_code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `semester_start` varchar(200) NOT NULL,
  `semester_end` varchar(200) NOT NULL,
  `academic_year_enrolled` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `stage` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Enrollments` VALUES ("249d30aef96c358ef960781df29fc927a701219928","ba52fc866349d5af05addecba35600d0fd970ef7ba","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","YFPQE30247","BSCMKS275517","Mart","Jan - Apr","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Advanced Probability And Statistics","BICM 1051","28 Jun 2021","","1st Year"),
("2cb2309401d0f51df57d9fb1f1f03237d2faf5056a","ba52fc866349d5af05addecba35600d0fd970ef7ba","","YRJGZ10398","BSCMKS275517","Mart","Jan - Apr","BCS","Bachelors In Computer Science","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Programming Principles","BSC 010","23 Jun 2021","",""),
("433afd1cb109b6de35d59a2847c2fb6ef8d2980266","ba52fc866349d5af05addecba35600d0fd970ef7ba","","OJNPQ62017","QRXDG76819","Martin","Jan - Apr","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Advanced Probability And Statistics","BICM 1051","28 Jun 2021","",""),
("8187c860c78cc220dc1b2522c8b12928e0d65cf60d","ba52fc866349d5af05addecba35600d0fd970ef7ba","02abafc898bc2b993cc646fff7fd94078442f33c1c","JQLGU58260","PZTFY90651","MartMbithi","Jan - Apr","CIQC","Certificate In Quantum Computing","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Quantum Computing 101","JOIVB34569","24 Jun 2021","","1st Year"),
("8365483e4a11cc16fb064ef717f46a0426303098f0","ba52fc866349d5af05addecba35600d0fd970ef7ba","","AQIDZ80364","QRXDG76819","Martin","Jan - Apr","CIQC","Certificate In Quantum Computing","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Quantum Computing 101","JOIVB34569","24 Jun 2021","",""),
("d0cba6714da52f19ebc854bf7c3f034af7dcac084d","ba52fc866349d5af05addecba35600d0fd970ef7ba","02abafc898bc2b993cc646fff7fd94078442f33c1c","RMEHG52749","BSCMKS275519","Mbithi","Jan - Apr","CIQC","Certificate In Quantum Computing","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Quantum Computing 101","JOIVB34569","24 Jun 2021","","1st Year");


DROP TABLE IF EXISTS `ezanaLMS_ExamQuestions`;

CREATE TABLE `ezanaLMS_ExamQuestions` (
  `id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `exam_time` varchar(200) NOT NULL,
  `instructions` longtext NOT NULL,
  `attachment` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_Faculties`;

CREATE TABLE `ezanaLMS_Faculties` (
  `id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `head` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Faculties` VALUES ("00b15efd5eca07d52d417d12d44dd457b98ea44282","UCRHE79058","School Of Medical And Medical Engineering","Mart","martdevelopers254@gmail.com","<p><b>Biomedical engineering</b> (<b>BME</b>) or <b>medical engineering</b>\r\n is the application of engineering principles and design concepts to \r\nmedicine and biology for healthcare purposes (e.g., diagnostic or \r\ntherapeutic). BME is also traditionally known as \"bioengineering\", but \r\nthis term has come to also refer to <a href=\"https://en.wikipedia.org/wiki/Biological_engineering\" title=\"Biological engineering\">biological engineering</a>. This field seeks to close the gap between <a href=\"https://en.wikipedia.org/wiki/Engineering\" title=\"Engineering\">engineering</a> and <a href=\"https://en.wikipedia.org/wiki/Medicine\" title=\"Medicine\">medicine</a>,\r\n combining the design and problem-solving skills of engineering with \r\nmedical biological sciences to advance health care treatment, including <a href=\"https://en.wikipedia.org/wiki/Medical_diagnosis\" title=\"Medical diagnosis\">diagnosis</a>, <a href=\"https://en.wikipedia.org/wiki/Medical_monitor\" class=\"mw-redirect\" title=\"Biomimetics\">monitoring</a>, and <a href=\"https://en.wikipedia.org/wiki/Therapy\" title=\"Therapy\">therapy</a>.<sup id=\"cite_ref-EnderleBronzino2012_1-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Biomedical_engineering#cite_note-EnderleBronzino2012-1\">[1]</a></sup><sup id=\"cite_ref-2\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Biomedical_engineering#cite_note-2\">[2]</a></sup>\r\n Also included under the scope of a biomedical engineer is the \r\nmanagement of current medical equipment in hospitals while adhering to \r\nrelevant industry standards. This involves making equipment \r\nrecommendations, procurement, routine testing, and preventive \r\nmaintenance, a role also known as a Biomedical Equipment Technician \r\n(BMET) or as <a href=\"https://en.wikipedia.org/wiki/Clinical_engineering\" title=\"Clinical engineering\">clinical engineering</a>.\r\n</p><p>Biomedical engineering has recently emerged as its own study, as \r\ncompared to many other engineering fields. Such an evolution is common \r\nas a new field transitions from being an <a href=\"https://en.wikipedia.org/wiki/Interdisciplinarity\" title=\"\">interdisciplinary</a>\r\n specialization among already-established fields to being considered a \r\nfield in itself. Much of the work in biomedical engineering consists of <a href=\"https://en.wikipedia.org/wiki/Research_and_development\" title=\"Research and development\">research and development</a>, spanning a broad array of subfields (see below). Prominent biomedical engineering applications include the development of <a href=\"https://en.wikipedia.org/wiki/Biocompatibility\" title=\"Biocompatibility\">biocompatible</a> <a href=\"https://en.wikipedia.org/wiki/Prosthesis\" title=\"Prosthesis\">prostheses</a>, various diagnostic and therapeutic <a href=\"https://en.wikipedia.org/wiki/Medical_device\" title=\"Medical device\">medical devices</a> ranging from clinical equipment to micro-implants, common imaging equipment such as <a href=\"https://en.wikipedia.org/wiki/MRI\" class=\"mw-redirect\" title=\"MRI\">MRIs</a> and <a href=\"https://en.wikipedia.org/wiki/EKG\" class=\"mw-redirect\" title=\"EKG\">EKG</a>/ECGs, <a href=\"https://en.wikipedia.org/wiki/Regeneration_(biology)\" title=\"Regeneration (biology)\">regenerative</a> tissue growth, pharmaceutical <a href=\"https://en.wikipedia.org/wiki/Medication\" title=\"Medication\">drugs</a> and therapeutic biologicals.\r\n</p>"),
("0d85bc9fb7a3954920a6dad46043ff1a86cb128c4b","ZBWGV84059","School Of Electrical Engineering","Ezana LMS Sys Admin","sysadmin@ezana.org","<p><b>Electrical engineering</b> is an <a href=\"https://en.wikipedia.org/wiki/Engineering\" title=\"Engineering\">engineering</a> discipline concerned with the study, design and application of equipment, devices and systems which use <a href=\"https://en.wikipedia.org/wiki/Electricity\" title=\"\">electricity</a>, <a href=\"https://en.wikipedia.org/wiki/Electronics\" title=\"Electronics\">electronics</a>, and <a href=\"https://en.wikipedia.org/wiki/Electromagnetism\" title=\"Electromagnetism\">electromagnetism</a>. It emerged as an identifiable occupation in the latter half of the 19th century after <a href=\"https://en.wikipedia.org/wiki/Commercialization\" title=\"Commercialization\">commercialization</a> of the <a href=\"https://en.wikipedia.org/wiki/Electric_telegraph\" class=\"mw-redirect\" title=\"Electric telegraph\">electric telegraph</a>, the <a href=\"https://en.wikipedia.org/wiki/Telephone\" title=\"Telephone\">telephone</a>, and <a href=\"https://en.wikipedia.org/wiki/Electrical_power\" class=\"mw-redirect\" title=\"Electrical power\">electrical power</a> generation, distribution and use.\r\n</p><p>Electrical engineering is now divided into a wide range of different fields, including <a href=\"https://en.wikipedia.org/wiki/Computer_engineering\" title=\"Computer engineering\">computer engineering</a>, <a href=\"https://en.wikipedia.org/wiki/Systems_engineering\" title=\"Systems engineering\">systems engineering</a>, <a href=\"https://en.wikipedia.org/wiki/Power_engineering\" title=\"Power engineering\">power engineering</a>, <a href=\"https://en.wikipedia.org/wiki/Telecommunication\" title=\"Telecommunication\">telecommunications</a>, <a href=\"https://en.wikipedia.org/wiki/Radio-frequency_engineering\" title=\"Radio-frequency engineering\">radio-frequency engineering</a>, <a href=\"https://en.wikipedia.org/wiki/Signal_processing\" title=\"Signal processing\">signal processing</a>, <a href=\"https://en.wikipedia.org/wiki/Instrumentation\" title=\"Instrumentation\">instrumentation</a>, <a href=\"https://en.wikipedia.org/wiki/Electronics\" title=\"Electronics\">electronics</a>, and <a href=\"https://en.wikipedia.org/wiki/Optics\" title=\"Optics\">optics</a> and <a href=\"https://en.wikipedia.org/wiki/Photonics\" title=\"Photonics\">photonics</a>.\r\n Many of these disciplines overlap with other engineering branches, \r\nspanning a huge number of specializations including hardware \r\nengineering, <a href=\"https://en.wikipedia.org/wiki/Power_electronics\" title=\"Power electronics\">power electronics</a>, electromagnetics and waves, <a href=\"https://en.wikipedia.org/wiki/Microwave_engineering\" title=\"Microwave engineering\">microwave engineering</a>, <a href=\"https://en.wikipedia.org/wiki/Nanotechnology\" title=\"Nanotechnology\">nanotechnology</a>, <a href=\"https://en.wikipedia.org/wiki/Electrochemistry\" title=\"Electrochemistry\">electrochemistry</a>, renewable energies, mechatronics, and electrical materials science.<sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Electrical_engineering#cite_note-1\">[a]</a></sup>\r\n</p><p>Electrical engineers typically hold a <a href=\"https://en.wikipedia.org/wiki/Academic_degree\" title=\"Academic degree\">degree</a> in electrical engineering or electronic engineering.  Practising engineers may have <a href=\"https://en.wikipedia.org/wiki/Professional_certification\" title=\"Professional certification\">professional certification</a> and be members of a <a href=\"https://en.wikipedia.org/wiki/Professional_body\" class=\"mw-redirect\" title=\"Professional body\">professional body</a> or an international standards organization. These include the <a href=\"https://en.wikipedia.org/wiki/International_Electrotechnical_Commission\" title=\"Electricity\">International Electrotechnical Commission</a> (IEC), the <a href=\"https://en.wikipedia.org/wiki/Institute_of_Electrical_and_Electronics_Engineers\" title=\"Institute of Electrical and Electronics Engineers\">Institute of Electrical and Electronics Engineers</a> (IEEE) and the <a href=\"https://en.wikipedia.org/wiki/Institution_of_Engineering_and_Technology\" title=\"Institution of Engineering and Technology\">Institution of Engineering and Technology</a> (IET) <i>(formerly the IEE)</i>.\r\n</p><p>Electrical engineers work in a very wide range of industries and the skills required are likewise variable. These range from <a href=\"https://en.wikipedia.org/wiki/Circuit_theory\" class=\"mw-redirect\" title=\"Circuit theory\">circuit theory</a> to the management skills of a <a href=\"https://en.wikipedia.org/wiki/Project_manager\" title=\"\">project manager</a>.  The tools and equipment that an individual engineer may need are similarly variable, ranging from a simple <a href=\"https://en.wikipedia.org/wiki/Voltmeter\" title=\"Voltmeter\">voltmeter</a> to sophisticated design and manufacturing software.\r\n</p>"),
("4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","YBJTD96340","School Of Business And Management Studies","Mr Johnes Doe","johnes@businessschool.ezana.org","<p><span style=\"font-family: &quot;Courier New&quot;;\">Computer science is the study of algorithmic processes, computational machines and computation itself. As a discipline, computer science spans a range of </span></p><p><span style=\"font-family: &quot;Courier New&quot;;\">topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.</span> </p>"),
("ba52fc866349d5af05addecba35600d0fd970ef7ba","KFQMH38140","School Of Computing Sciences","Ezana LMS Sys Admin","sysadmin@ezana.org","Computer science is the study of algorithmic processes, computational machines and computation itself. As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software. <br>");


DROP TABLE IF EXISTS `ezanaLMS_Groups`;

CREATE TABLE `ezanaLMS_Groups` (
  `id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Groups` VALUES ("869f1154ffbbae52a999f45ae06112c6bdd3bc70f5","acf6b89d367d2c6859ed9acf0d9f92de81f1ca3379","ba52fc866349d5af05addecba35600d0fd970ef7ba","VNSFA53672","Alpha G","<p>Just another test group<br></p>","2021-06-16 15:05:39",""),
("8a2bd344c86dc2f747dfd5ce157a60444a4f584bfc","3699d9d9a098a82802aa8f2e674de7808d07cdcd52","ba52fc866349d5af05addecba35600d0fd970ef7ba","GIMSC01274","Alpha Group","<p>Just another group<br></p>","2021-06-16 16:00:02",""),
("9a592b5fc458738ed8aae99b7f95398fb4d773cf54","00a3fb07813faa9c365e264a1a565934d09601d39b","ba52fc866349d5af05addecba35600d0fd970ef7ba","BUXQG02571","Group Alpha","<p>Just a group details.<br></p>","2021-06-15 15:31:05",""),
("c62acc77e8cd1e7c192d432f29025871bcc45aeeb3","69488c64666d64defa40625c14e92323c27d7fa0ed","ba52fc866349d5af05addecba35600d0fd970ef7ba","TPIRJ13872","Group Beta","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Purus gravida quis \r\nblandit turpis cursus in hac. Ante in nibh mauris cursus mattis. Quis \r\nvarius quam quisque id diam vel quam. Vitae elementum curabitur vitae \r\nnunc sed velit dignissim. Consequat interdum varius sit amet mattis \r\nvulputate enim nulla. Porttitor lacus luctus accumsan tortor. Mi \r\nbibendum neque egestas congue quisque egestas diam in arcu. Velit \r\neuismod in pellentesque massa placerat duis ultricies lacus. Nunc \r\npulvinar sapien et ligula. Placerat duis ultricies lacus sed turpis.</p>\r\n<p><br></p></div>","2021-06-25 10:20:22","");


DROP TABLE IF EXISTS `ezanaLMS_GroupsAnnouncements`;

CREATE TABLE `ezanaLMS_GroupsAnnouncements` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `group_code` varchar(200) NOT NULL,
  `group_name` varchar(200) NOT NULL,
  `announcement` longblob NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_GroupsAnnouncements` VALUES ("40fd47a67297e88d3ef77b51f181c94919c28c6074","","TPIRJ13872","Group Beta","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Purus gravida quis \r\nblandit turpis cursus in hac. Ante in nibh mauris cursus mattis. Quis \r\nvarius quam quisque id diam vel quam. Vitae elementum curabitur vitae \r\nnunc sed velit dignissim. Consequat interdum varius sit amet mattis \r\nvulputate enim nulla. <br></p>\r\n<p><br></p></div>","Ezana LMS Sys Admin","2021-06-25 10:50:09","25 Jun 2021"),
("b9ed5fe8f7715579efe0adb44e479a3647c6ace7f2","","TPIRJ13872","Group Beta","<div class=\"page-generator__output js-generator-output\" id=\"output\">\r\n<p>Praesent semper feugiat nibh sed pulvinar proin gravida. Quam id leo \r\nin vitae. Vitae semper quis lectus nulla at volutpat. Proin sagittis \r\nnisl rhoncus mattis rhoncus urna neque viverra justo. In eu mi bibendum \r\nneque egestas. Sit amet luctus venenatis lectus magna. Ultrices neque \r\nornare aenean euismod elementum. A condimentum vitae sapien pellentesque\r\n habitant morbi tristique senectus et. Rhoncus mattis rhoncus urna \r\nneque. Porta nibh venenatis cras sed felis eget velit. Diam donec \r\nadipiscing tristique risus nec feugiat in. Morbi non arcu risus quis \r\nvarius quam. Faucibus ornare suspendisse sed nisi lacus sed viverra \r\ntellus. Feugiat nisl pretium fusce id velit ut tortor. Ut etiam sit amet\r\n nisl purus in mollis. In hac habitasse platea dictumst vestibulum \r\nrhoncus est pellentesque elit. Maecenas pharetra convallis posuere \r\nmorbi. Fermentum posuere urna nec tincidunt praesent semper.</p></div>","Ezana LMS Sys Admin","2021-06-25 10:50:36","");


DROP TABLE IF EXISTS `ezanaLMS_GroupsAssignments`;

CREATE TABLE `ezanaLMS_GroupsAssignments` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `group_code` varchar(200) NOT NULL,
  `group_name` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `submitted_on` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_GroupsAssignments` VALUES ("2b21bee00d7cb36afe040eb2a754173615d0d4f3f0","ba52fc866349d5af05addecba35600d0fd970ef7ba","00a3fb07813faa9c365e264a1a565934d09601d39b","BUXQG02571","Group Alpha","","<p>Find the attached document.<br></p>","15-Jun-2021-1623760364dummy.pdf","2021-06-15","2021-06-15 15:32:44",""),
("877420f4d26cfd6cf360c765b0b5b8f8d5caa453df","ba52fc866349d5af05addecba35600d0fd970ef7ba","69488c64666d64defa40625c14e92323c27d7fa0ed","TPIRJ13872","Group Beta","","<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Purus gravida quis \r\nblandit turpis cursus in hac. Ante in nibh mauris cursus mattis. Quis \r\nvarius quam quisque id diam vel quam. Vitae elementum curabitur vitae \r\nnunc sed velit dignissim. Consequat interdum varius sit amet mattis \r\nvulputate enim nulla. Porttitor lacus luctus accumsan tortor. Mi \r\nbibendum neque egestas congue quisque egestas diam in arcu. Velit \r\neuismod in pellentesque massa placerat duis ultricies lacus. Nunc \r\npulvinar sapien et ligula. Placerat duis ultricies lacus sed turpis.</p>\r\n<p><br></p></div>","1624607802dummy.pdf","06/30/2021 10:55 AM","2021-06-25 10:56:42",""),
("c95ae1de177556e667e1269498917b002d56635874","ba52fc866349d5af05addecba35600d0fd970ef7ba","3699d9d9a098a82802aa8f2e674de7808d07cdcd52","GIMSC01274","Alpha Group","","<p>Just another assignment.<br></p>","16-Jun-2021-1623848775dummy.pdf","2021-06-16","2021-06-16 16:06:15",""),
("d85b9bf00c5e323bece264d4b07af8098bc970674f","ba52fc866349d5af05addecba35600d0fd970ef7ba","acf6b89d367d2c6859ed9acf0d9f92de81f1ca3379","VNSFA53672","Alpha G","","<p>Just another group assignment.<br></p>","16-Jun-2021-1623845293dummy.pdf","2021-06-16","2021-06-16 15:08:13","");


DROP TABLE IF EXISTS `ezanaLMS_GroupsAssignmentsGrades`;

CREATE TABLE `ezanaLMS_GroupsAssignmentsGrades` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `group_name` varchar(200) NOT NULL,
  `group_code` varchar(200) NOT NULL,
  `project_id` varchar(200) NOT NULL,
  `Submitted_Files` longtext NOT NULL,
  `group_score` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_GroupsAssignmentsGrades` VALUES ("1b3464ae7d976e08c6b3cebc2020f7ba068b5d11fe","ba52fc866349d5af05addecba35600d0fd970ef7ba","Alpha Group","GIMSC01274","c95ae1de177556e667e1269498917b002d56635874","16-Jun-2021-1623849370dummy.pdf","","2021-06-16 16:16:10");


DROP TABLE IF EXISTS `ezanaLMS_Lecturers`;

CREATE TABLE `ezanaLMS_Lecturers` (
  `id` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `idno` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `adr` longtext NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `faculty_name` varchar(200) NOT NULL,
  `work_email` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `date_employed` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Lecturers` VALUES ("55e4c3bfa7716eee2762ff39e7d69d3128a214d776","RIUTG62145","Mart Developers",355790893,07100100901,"martdevelopers254@gmail.com","90126 Localhost","ce86da04d57969d73306a3cce40c23dff8b4a0e6","","21 Jun 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","Computer Science","martdevelopers254@gmail.com","Male",90126,"2021-06-21","On Leave"),
("6251b4c29c7303f282f08f35a28ecb15db4302c259","LSPWT31950","MartinMbithi",9009009,0710090901,"martinezmbithi@gmail.com","90126 Localhost","c4b74bdca305b98418f702ce85078b7c0232e1d9","1624363274_DSC9753.JPG","22 Jun 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","martinezmbithi@gmail.com","Female",901276781,"2021-06-22","");


DROP TABLE IF EXISTS `ezanaLMS_ModuleAssignments`;

CREATE TABLE `ezanaLMS_ModuleAssignments` (
  `id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `submission_deadline` varchar(200) NOT NULL,
  `attachments` longtext NOT NULL,
  `faculty` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_ModuleAssignments` VALUES ("0c39ecd0aa2897b6eae9dd33e5e9756509b6726750","JOIVB34569","Assignment 1","Quantum Computing 101","2021-06-25 09:59:41","06/25/2021 10:55 PM","1624604381dummy.pdf","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("d22abc9add171b7f9e1285e7b597ad01ff8a259e2d","BCS 1190","","Object Oriented Programming","2021-06-16 15:59:20","2021-06-16","16-Jun-2021-1623848360dummy.pdf","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("d49811ef745aca1a0e816ec0eee6b78613cf23f78c","DICS 1010","","Digital Electronics 1","2021-06-16 15:03:33","2021-06-16","16-Jun-2021-1623845013dummy.pdf","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("e9fe0c1b33cfd2e6351d511a900e3330629c59f8de","BICM 1051","Cat 1","Advanced Probability And Statistics","2021-06-28 20:02:20","06/28/2021 8:02 PM","1624899740dummy.pdf","ba52fc866349d5af05addecba35600d0fd970ef7ba");


DROP TABLE IF EXISTS `ezanaLMS_ModuleAssigns`;

CREATE TABLE `ezanaLMS_ModuleAssigns` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lec_id` varchar(200) NOT NULL,
  `lec_name` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `academic_year` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_ModuleAssigns` VALUES ("4249da7b2eee9400564b3fe2a442c1df00264cc98c","ba52fc866349d5af05addecba35600d0fd970ef7ba","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","","BICM 1051","Advanced Probability And Statistics","55e4c3bfa7716eee2762ff39e7d69d3128a214d776","Mart Developers","23 Jun 2021","","Guest Lecturer","Sep 2020 - Sep 2021 ","Jan - Apr "),
("8dcb362c87884fd194d109d080bf4654e2170bf2d8","ba52fc866349d5af05addecba35600d0fd970ef7ba","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","","BICM 1051","Advanced Probability And Statistics","55e4c3bfa7716eee2762ff39e7d69d3128a214d776","Mart Developers","23 Jun 2021","","Guest Lecturer","Sep 2020 - Sep 2021 ","Jan - Apr "),
("bef3364295a28b85aee911ff73bae08175057913e5","ba52fc866349d5af05addecba35600d0fd970ef7ba","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","052b62a629819a6e165078fab7071dec9f541f5321","BICM 103","Numerical Computation","55e4c3bfa7716eee2762ff39e7d69d3128a214d776","Mart Developers","22 Jun 2021","","","Sep 2020 - Sep 2021 ","Jan - Apr "),
("c4780b3d0f97197da1e0e1727072bcb0905481b3b3","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","5e4b1611c4e4f0a08fdb5836c36df64e66cc1590de","","LJVWQ52178","Procurement 101","6251b4c29c7303f282f08f35a28ecb15db4302c259","MartinMbithi","24 Jun 2021","","","Sep 2020 - Sep 2021 ","Jan - Apr "),
("c94d5514d83591ebc4f58f5820eb4dae50ae8a658f","ba52fc866349d5af05addecba35600d0fd970ef7ba","69488c64666d64defa40625c14e92323c27d7fa0ed","","JOIVB34569","Quantum Computing 101","55e4c3bfa7716eee2762ff39e7d69d3128a214d776","Mart Developers","24 Jun 2021","","","Sep 2020 - Sep 2021 ","Jan - Apr "),
("e712c5081365c689d152ceab9e0a50eef745b08f64","ba52fc866349d5af05addecba35600d0fd970ef7ba","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","","BICM 101","Linear Algebra","55e4c3bfa7716eee2762ff39e7d69d3128a214d776","Mart Developers","23 Jun 2021","","","Sep 2020 - Sep 2021 ","Jan - Apr ");


DROP TABLE IF EXISTS `ezanaLMS_ModuleMemo`;

CREATE TABLE `ezanaLMS_ModuleMemo` (
  `id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_memo` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `faculty_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_ModuleRecommended`;

CREATE TABLE `ezanaLMS_ModuleRecommended` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `readingMaterials` varchar(200) NOT NULL,
  `topic` longtext NOT NULL,
  `external_link` varchar(200) NOT NULL,
  `visibility` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_ModuleRecommended` VALUES ("721b82135cadcadfb3748b4248a088657272e3657c","ba52fc866349d5af05addecba35600d0fd970ef7ba","JOIVB34569","Quantum Computing 101","1624531568dummy.pdf","Future Of Computing","","Hidden","2021-06-24 13:48:14"),
("88c9313f15792ffe9e64b6f71627b824572f9f006d","ba52fc866349d5af05addecba35600d0fd970ef7ba","DICS 1010","Digital Electronics 1","16-Jun-2021-1623844631dummy.pdf","","","Available","2021-06-16 14:57:11"),
("a4759983eda0119db5aae332314ef17cb8a6eceb86","ba52fc866349d5af05addecba35600d0fd970ef7ba","JOIVB34569","Quantum Computing 101","1624531669dummy.pdf","Computing Technologies","","Hidden","2021-06-24 13:48:07"),
("a855ea75f2b4fb8088ee6c38f9e0512f9663b745b5","ba52fc866349d5af05addecba35600d0fd970ef7ba","JOIVB34569","Quantum Computing 101","1624531165dummy.pdf","Quantum Computing Deep Dive","","Available","2021-06-24 13:44:17"),
("bcc2f3eb71a457ac25fedd699c862dae46d3e20022","ba52fc866349d5af05addecba35600d0fd970ef7ba","BICM 1051","Advanced Probability And Statistics","15-Jun-2021-1623759649dummy.pdf","","","Available","2021-06-15 15:20:49"),
("dfaa865fadaa341fa75173e69a86d346478475ddc1","ba52fc866349d5af05addecba35600d0fd970ef7ba","BCS 1190","Object Oriented Programming","16-Jun-2021-1623848238dummy.pdf","","","Available","2021-06-16 15:57:18"),
("f78f112cfe2461249319700f36fdc6614335bb52df","ba52fc866349d5af05addecba35600d0fd970ef7ba","JOIVB34569","Quantum Computing 101","1624530172dummy.pdf","An Introduction to Quantum Computing","https://arxiv.org/abs/0708.0261","Available","2021-06-24 13:33:41");


DROP TABLE IF EXISTS `ezanaLMS_Modules`;

CREATE TABLE `ezanaLMS_Modules` (
  `id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `course_duration` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `exam_weight_percentage` varchar(200) NOT NULL,
  `cat_weight_percentage` varchar(200) NOT NULL,
  `lectures_number` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `ass_status` tinyint(2) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Modules` VALUES ("00a3fb07813faa9c365e264a1a565934d09601d39b","BICM 1051","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Advanced Probability And Statistics",50,50,5,"<p>Advanced Probability And Statistics is an advanced course in computational mathematics course.<br></p>",1,"22 Apr 2021","24 Jun 2021"),
("052b62a629819a6e165078fab7071dec9f541f5321","BICM 103","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Numerical Computation","70 %","30 %",4,"<p>Numerical analysis is the study of algorithms that use numerical approximation (as opposed to symbolic manipulations) for the problems of mathematical analysis (as distinguished from discrete mathematics). Numerical analysis naturally finds application in all fields of engineering and the physical sciences, but in the 21st century also the life sciences, social sciences, medicine, business and even the arts have adopted elements of scientific computations. The growth in computing power has revolutionized the use of realistic mathematical models in science and engineering, and subtle numerical analysis is required to implement these detailed models of the world. For example, ordinary differential equations appear in celestial mechanics (predicting the motions of planets, stars and galaxies); numerical linear algebra is important for data analysis;[2][3][4]</p><p> stochastic differential equations and Markov chains are essential in simulating living cells for medicine and biology.\r\n\r\nBefore the advent of modern computers, numerical methods often depended on hand interpolation formulas applied to data from large printed tables. Since the mid 20th century, computers calculate the required functions instead, but many of the same formulas nevertheless continue to be used as part of the software algorithms.[5]\r\n\r\nThe numerical point of view goes back to the earliest mathematical writings. A tablet from the Yale Babylonian Collection (YBC 7289), gives a sexagesimal numerical approximation of the square root of 2, the length of the diagonal in a unit square.\r\n\r\nNumerical analysis continues this long tradition: rather than exact symbolic answers, which can only be applied to real-world measurements by translation into digits, it gives approximate solutions within specified error bounds. </p>",1,"29 Mar 2021","26 Apr 2021"),
("2d967413c7030aaa678d6396fcdedf8da367c78bcf","LJVWQ52178","Procurement","5e4b1611c4e4f0a08fdb5836c36df64e66cc1590de","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","3 Hrs","Procurement 101",50,50,5,"<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Porta nibh venenatis\r\n cras sed. A erat nam at lectus urna duis convallis convallis tellus. \r\nCommodo sed egestas egestas fringilla phasellus faucibus scelerisque. \r\nCursus eget nunc scelerisque viverra mauris in aliquam sem fringilla. \r\nLacinia quis vel eros donec ac odio. Vestibulum lectus mauris ultrices \r\neros in. Quis varius quam quisque id diam vel quam elementum. Consequat \r\ninterdum varius sit amet mattis vulputate enim nulla aliquet. Odio eu \r\nfeugiat pretium nibh ipsum consequat nisl vel pretium. Neque vitae \r\ntempus quam pellentesque nec nam aliquam sem. Amet purus gravida quis \r\nblandit turpis cursus in. Sit amet consectetur adipiscing elit ut \r\naliquam purus sit amet. Tempor orci dapibus ultrices in iaculis nunc \r\nsed. Ac auctor augue mauris augue neque gravida in fermentum. Mollis \r\nnunc sed id semper risus in hendrerit gravida.</p>\r\n<p>Sem nulla pharetra diam sit. Pellentesque nec nam aliquam sem et \r\ntortor. Nisl vel pretium lectus quam id leo in. Varius morbi enim nunc \r\nfaucibus a pellentesque sit. In tellus integer feugiat scelerisque \r\nvarius morbi enim nunc faucibus. Viverra aliquet eget sit amet tellus \r\ncras adipiscing. Quam lacus suspendisse faucibus interdum posuere lorem.\r\n Dolor purus non enim praesent elementum facilisis leo vel. Nunc \r\nlobortis mattis aliquam faucibus purus in massa tempor. Fames ac turpis \r\negestas integer eget aliquet nibh praesent tristique.</p></div>",1,"23 Jun 2021","24 Jun 2021"),
("3699d9d9a098a82802aa8f2e674de7808d07cdcd52","BCS 1190","Bachelors In Computer Science","49943644fdc0a65810f0c2f58de2ec69d0c8a9d307","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Object Oriented Programming","70 %","30 %",2,"<p>Object-oriented programming (OOP) is a programming paradigm based on the concept of \"objects\", which can contain data and code: data in the form of fields (often known as attributes or properties), and code, in the form of procedures (often known as methods).\r\n\r\nA feature of objects is that an object\'s own procedures can access and often modify the data fields of itself (objects have a notion of this or self). In OOP, computer programs are designed by making them out of objects that interact with one another.[1][2]</p><p> OOP languages are diverse, but the most popular ones are class-based, meaning that objects are instances of classes, which also determine their types.\r\n\r\nMany of the most widely used programming languages (such as C++, Java, Python, etc.) are multi-paradigm and they support object-oriented programming to a greater or lesser degree, typically in combination with imperative, procedural programming. Significant object-oriented languages include: (list order based on TIOBE index) Java, C++, C#, Python, R, PHP, Visual Basic.NET, JavaScript, Ruby, Perl, Object Pascal, Objective-C, Dart, Swift, Scala, Kotlin, Common Lisp, MATLAB, and Smalltalk. </p>",0,"31 Mar 2021","23 Apr 2021"),
("5d06eacbf35dc90d6602e85393bb27a51f433fddf4","UDPQA13486","Diploma In Computer Science","9bd615c255bc533378e946171d9b8fa61980605a70","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Information Systems","70 %","30 %",4,"<p>Information systems is a core  diploma module.<br></p>",0,"19 Apr 2021","19 Apr 2021"),
("69488c64666d64defa40625c14e92323c27d7fa0ed","JOIVB34569","Certificate In Quantum Computing","02abafc898bc2b993cc646fff7fd94078442f33c1c","ba52fc866349d5af05addecba35600d0fd970ef7ba","3 Hrs ","Quantum Computing 101",50,50,4,"<p><b>Quantum computing</b> is the exploitation of collective properties of <a href=\"https://en.wikipedia.org/wiki/Quantum_physics\" class=\"mw-redirect\" title=\"Quantum physics\">quantum</a> states, such as <a href=\"https://en.wikipedia.org/wiki/Quantum_superposition\" title=\"Quantum superposition\">superposition</a> and <a href=\"https://en.wikipedia.org/wiki/Quantum_entanglement\" title=\"Quantum entanglement\">entanglement</a>, to perform <a href=\"https://en.wikipedia.org/wiki/Computation\" title=\"Computation\">computation</a>. The devices that perform quantum computations are known as <b>quantum computers</b>.<sup id=\"cite_ref-2018Report_1-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-2018Report-1\">[1]</a></sup><sup class=\"reference\" style=\"white-space:nowrap;\">:<span>I-5</span></sup> They are believed to be able to solve certain <a href=\"https://en.wikipedia.org/wiki/Computational_problem\" title=\"Computational problem\">computational problems</a>, such as <a href=\"https://en.wikipedia.org/wiki/Integer_factorization\" title=\"Integer factorization\">integer factorization</a> (which underlies <a href=\"https://en.wikipedia.org/wiki/RSA_encryption\" class=\"mw-redirect\" title=\"\">RSA encryption</a>), substantially faster than classical computers. The study of quantum computing is a subfield of <a href=\"https://en.wikipedia.org/wiki/Quantum_information_science\" title=\"Quantum information science\">quantum information science</a>.\r\n Expansion is expected in the next few years as the field shifts toward \r\nreal-world use in pharmaceutical, data security and other applications.<sup id=\"cite_ref-2\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-2\">[2]</a></sup>\r\n</p><p>Quantum computing began in 1980 when physicist <a href=\"https://en.wikipedia.org/wiki/Paul_Benioff\" title=\"Paul Benioff\">Paul Benioff</a> proposed a <a href=\"https://en.wikipedia.org/wiki/Quantum_mechanics\" title=\"Quantum mechanics\">quantum mechanical</a> model of the <a href=\"https://en.wikipedia.org/wiki/Turing_machine\" title=\"Turing machine\">Turing machine</a>.<sup id=\"cite_ref-The_computer_as_a_physical_system_3-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-The_computer_as_a_physical_system-3\">[3]</a></sup> <a href=\"https://en.wikipedia.org/wiki/Richard_Feynman\" title=\"Richard Feynman\">Richard Feynman</a> and <a href=\"https://en.wikipedia.org/wiki/Yuri_Manin\" title=\"Yuri Manin\">Yuri Manin</a> later suggested that a quantum computer had the potential to simulate things a <a href=\"https://en.wikipedia.org/wiki/Computer\" title=\"Computer\">classical computer</a> could not feasibly do.<sup id=\"cite_ref-4\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-4\">[4]</a></sup><sup id=\"cite_ref-manin1980vychislimoe_5-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-manin1980vychislimoe-5\">[5]</a></sup>  In 1994, <a href=\"https://en.wikipedia.org/wiki/Peter_Shor\" title=\"Peter Shor\">Peter Shor</a> developed a quantum <a href=\"https://en.wikipedia.org/wiki/Algorithm\" title=\"Algorithm\">algorithm</a> for <a href=\"https://en.wikipedia.org/wiki/Integer_factorization\" title=\"Integer factorization\">factoring integers</a> with the potential to decrypt <a href=\"https://en.wikipedia.org/wiki/RSA_(cryptosystem)\" title=\"RSA (cryptosystem)\">RSA</a>-encrypted communications.<sup id=\"cite_ref-6\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-6\">[6]</a></sup> Despite ongoing experimental progress since the late 1990s, most researchers believe that \"<a href=\"https://en.wikipedia.org/wiki/Quantum_threshold_theorem\" title=\"Quantum threshold theorem\">fault-tolerant</a> quantum computing [is] still a rather distant dream.\"<sup id=\"cite_ref-preskill2018_7-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-preskill2018-7\">[7]</a></sup> In recent years, investment in quantum computing research has increased in the public and private sectors.<sup id=\"cite_ref-8\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-8\">[8]</a></sup><sup id=\"cite_ref-9\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-9\">[9]</a></sup> On 23 October 2019, <a href=\"https://en.wikipedia.org/wiki/Google_AI\" title=\"Google AI\">Google AI</a>, in partnership with the U.S. National Aeronautics and Space Administration (<a href=\"https://en.wikipedia.org/wiki/NASA\" title=\"NASA\">NASA</a>), claimed to have performed a quantum computation that was <a href=\"https://en.wikipedia.org/wiki/Quantum_supremacy\" title=\"Quantum supremacy\">infeasible on any classical computer</a>.<sup id=\"cite_ref-10\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-10\">[10]</a></sup>\r\n</p><p>There are several types of quantum computers (or rather, quantum computing systems), including the <a href=\"https://en.wikipedia.org/wiki/Quantum_circuit\" title=\"Quantum circuit\">quantum circuit model</a>, <a href=\"https://en.wikipedia.org/wiki/Quantum_Turing_machine\" title=\"Quantum Turing machine\">quantum Turing machine</a>, <a href=\"https://en.wikipedia.org/wiki/Adiabatic_quantum_computation\" title=\"Adiabatic quantum computation\">adiabatic quantum computer</a>, <a href=\"https://en.wikipedia.org/wiki/One-way_quantum_computer\" title=\"One-way quantum computer\">one-way quantum computer</a>, and various <a href=\"https://en.wikipedia.org/wiki/Quantum_cellular_automata\" class=\"mw-redirect\" title=\"Quantum cellular automata\">quantum cellular automata</a>. The most widely used model is the <a href=\"https://en.wikipedia.org/wiki/Quantum_circuit\" title=\"Quantum circuit\">quantum circuit</a>, based on the quantum bit, or \"<a href=\"https://en.wikipedia.org/wiki/Qubit\" title=\"Qubit\">qubit</a>\", which is somewhat analogous to the <a href=\"https://en.wikipedia.org/wiki/Bit\" title=\"Bit\">bit</a> in classical computation. A qubit can be in a 1 or 0 <a href=\"https://en.wikipedia.org/wiki/Quantum_state\" title=\"Quantum state\">quantum state</a>, or in a superposition of the 1 and 0 states. When it is measured, however, it is always 0 or 1; the <a href=\"https://en.wikipedia.org/wiki/Probability\" title=\"Probability\">probability</a> of either outcome depends on the qubit\'s quantum state immediately prior to measurement.\r\n</p><p>Efforts towards building a physical quantum computer focus on technologies such as <a href=\"https://en.wikipedia.org/wiki/Transmon\" title=\"Transmon\">transmons</a>, <a href=\"https://en.wikipedia.org/wiki/Trapped_ion_quantum_computer\" title=\"Trapped ion quantum computer\">ion traps</a> and <a href=\"https://en.wikipedia.org/wiki/Topological_quantum_computer\" title=\"Topological quantum computer\">topological quantum computers</a>, which aim to create high-quality qubits.<sup id=\"cite_ref-2018Report_1-1\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-2018Report-1\">[1]</a></sup><sup class=\"reference\" style=\"white-space:nowrap;\">:<span>2–13</span></sup> These qubits may be designed differently, depending on the full quantum computer\'s computing model, whether <a href=\"https://en.wikipedia.org/wiki/Quantum_logic_gate\" title=\"Quantum logic gate\">quantum logic gates</a>, <a href=\"https://en.wikipedia.org/wiki/Quantum_annealing\" title=\"Quantum annealing\">quantum annealing</a>, or <a href=\"https://en.wikipedia.org/wiki/Adiabatic_quantum_computation\" title=\"Adiabatic quantum computation\">adiabatic quantum computation</a>.\r\n There are currently a number of significant obstacles to constructing \r\nuseful quantum computers. It is particularly difficult to maintain \r\nqubits\' quantum states, as they suffer from <a href=\"https://en.wikipedia.org/wiki/Quantum_decoherence\" title=\"Quantum decoherence\">quantum decoherence</a> and <a href=\"https://en.wikipedia.org/wiki/Fidelity_of_quantum_states\" title=\"Fidelity of quantum states\">state fidelity</a>. Quantum computers therefore require <a href=\"https://en.wikipedia.org/wiki/Quantum_error_correction\" title=\"Quantum error correction\">error correction</a>.<sup id=\"cite_ref-11\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-11\">[11]</a></sup><sup id=\"cite_ref-12\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-12\">[12]</a></sup>\r\n</p><p>Any computational problem that can be solved by a classical computer can also be solved by a quantum computer.<sup id=\"cite_ref-Nielsen,_p._29_13-0\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/Quantum_computing#cite_note-Nielsen,_p._29-13\">[13]</a></sup>\r\n Conversely, any problem that can be solved by a quantum computer can \r\nalso be solved by a classical computer, at least in principle given \r\nenough time. In other words, quantum computers obey the <a href=\"https://en.wikipedia.org/wiki/Church%E2%80%93Turing_thesis\" title=\"Church–Turing thesis\">Church–Turing thesis</a>. This means that while quantum computers provide no additional advantages over classical computers in terms of <a href=\"https://en.wikipedia.org/wiki/Computability\" title=\"Computability\">computability</a>, <a href=\"https://en.wikipedia.org/wiki/Quantum_algorithm\" title=\"Quantum algorithm\">quantum algorithms</a> for certain problems have significantly lower <a href=\"https://en.wikipedia.org/wiki/Time_complexity\" title=\"Time complexity\">time complexities</a>\r\n than corresponding known classical algorithms. Notably, quantum \r\ncomputers are believed to be able to quickly solve certain problems that\r\n no classical computer could solve in any <i>feasible</i> amount of time—a feat known as \"quantum supremacy.\" The study of the <a href=\"https://en.wikipedia.org/wiki/Computational_complexity\" title=\"Computational complexity\">computational complexity</a> of problems with respect to quantum computers is known as <a href=\"https://en.wikipedia.org/wiki/Quantum_complexity_theory\" title=\"Quantum complexity theory\">quantum complexity theory</a>.\r\n</p>",1,"21 Apr 2021","24 Jun 2021"),
("83df2612da68c0243ccbf3836a78f6ec2cc1575014","BICM 1050","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Probability And Statistics","70 %","30 %",3,"<p>Probability And Statistics is a core module in computational mathematics.<br></p>",0,"22 Apr 2021",""),
("99790cb6e677abf385fba8b96591580519bbaba22d","XKYHF58901","Procurement","5e4b1611c4e4f0a08fdb5836c36df64e66cc1590de","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","3 Hours","Supply Chain Management",70,30,5,"<div class=\"page-generator__output js-generator-output\" id=\"output\"><p>Lorem\r\n ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. At tellus at urna \r\ncondimentum mattis pellentesque. Libero justo laoreet sit amet. At \r\nvarius vel pharetra vel. Quam pellentesque nec nam aliquam sem et tortor\r\n consequat. Semper risus in hendrerit gravida. Dui faucibus in ornare \r\nquam viverra orci sagittis eu. Sit amet consectetur adipiscing elit. \r\nJusto eget magna fermentum iaculis. Eu facilisis sed odio morbi quis \r\ncommodo odio aenean. Tellus pellentesque eu tincidunt tortor aliquam \r\nnulla facilisi cras fermentum. Habitant morbi tristique senectus et \r\nnetus et malesuada fames ac. Ullamcorper a lacus vestibulum sed arcu. \r\nDiam quam nulla porttitor massa id neque aliquam. Duis at consectetur \r\nlorem donec massa. Diam maecenas sed enim ut sem viverra aliquet eget \r\nsit. Ipsum dolor sit amet consectetur adipiscing elit duis tristique. \r\nGravida neque convallis a cras semper. Quis risus sed vulputate odio ut \r\nenim.</p>\r\n<p>Ac turpis egestas integer eget aliquet nibh praesent tristique magna.\r\n Consequat interdum varius sit amet mattis. Amet luctus venenatis lectus\r\n magna fringilla urna porttitor. Quis viverra nibh cras pulvinar mattis \r\nnunc sed. Tincidunt dui ut ornare lectus sit. Ipsum consequat nisl vel \r\npretium lectus quam. Faucibus et molestie ac feugiat. A arcu cursus \r\nvitae congue mauris rhoncus aenean vel. Phasellus faucibus scelerisque \r\neleifend donec pretium vulputate sapien nec sagittis. Ut sem viverra \r\naliquet eget sit amet tellus. Interdum velit euismod in pellentesque \r\nmassa placerat. Nisi vitae suscipit tellus mauris a diam maecenas sed. \r\nNec feugiat nisl pretium fusce id velit ut. Euismod quis viverra nibh \r\ncras pulvinar mattis nunc sed blandit. Purus non enim praesent elementum\r\n facilisis leo vel fringilla. Est lorem ipsum dolor sit amet \r\nconsectetur. Purus faucibus ornare suspendisse sed nisi lacus sed \r\nviverra tellus.</p></div>",0,"24 Jun 2021",""),
("b64d04da5331ebd753398d7c73ad69958048d5d9fe","BICM 102","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Basic Calculus",70,30,2,"<p>Calculus, originally called infinitesimal calculus or \"the calculus of infinitesimals\", is the mathematical study of continuous change, in the same way that geometry is the study of shape and algebra is the study of generalizations of arithmetic operations.\r\n\r\nIt has two major branches, differential calculus and integral calculus; the former concerns instantaneous rates of change, and the slopes of curves, while integral calculus concerns accumulation of quantities, and areas under or between curves. These two branches are related to each other by the fundamental theorem of calculus, and they make use of the fundamental notions of convergence of infinite sequences and infinite series to a well-defined limit.[1]\r\n\r\nInfinitesimal calculus was developed independently in the late 17th century by Isaac Newton and Gottfried Wilhelm Leibniz.[2][3]</p><p> Today, calculus has widespread uses in science, engineering, and economics.[4]\r\n\r\nIn mathematics education, calculus denotes courses of elementary mathematical analysis, which are mainly devoted to the study of functions and limits. The word calculus (plural calculi) is a Latin word, meaning originally \"small pebble\" (this meaning is kept in medicine – see Calculus (medicine)). Because such pebbles were used for counting (or measuring) a distance travelled by transportation devices in use in ancient Rome[5], the meaning of the word has evolved and today usually means a method of computation. It is therefore used for naming specific methods of calculation and related theories, such as propositional calculus, Ricci calculus, calculus of variations, lambda calculus, and process calculus. </p>",0,"29 Mar 2021","24 Jun 2021"),
("b9adc76da9eb039117c5e9b7bcbe302b0262f5744a","BICM 101","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Linear Algebra","70 %","30 %",2,"Linear algebra is the branch of mathematics concerning linear equations such as:\r\n\r\n    a 1 x 1 + ⋯ + a n x n = b , {\\displaystyle a_{1}x_{1}+\\cdots +a_{n}x_{n}=b,} {\\displaystyle a_{1}x_{1}+\\cdots +a_{n}x_{n}=b,}\r\n\r\nlinear maps such as:\r\n\r\n    ( x 1 , … , x n ) ↦ a 1 x 1 + ⋯ + a n x n , {\\displaystyle (x_{1},\\ldots ,x_{n})\\mapsto a_{1}x_{1}+\\cdots +a_{n}x_{n},} {\\displaystyle (x_{1},\\ldots ,x_{n})\\mapsto a_{1}x_{1}+\\cdots +a_{n}x_{n},}\r\n\r\nand their representations in vector spaces and through matrices.[1][2][3]\r\n\r\nLinear algebra is central to almost all areas of mathematics. For instance, linear algebra is fundamental in modern presentations of geometry, including for defining basic objects such as lines, planes and rotations. Also, functional analysis, a branch of mathematical analysis, may be viewed as basically the application of linear algebra to spaces of functions.\r\n\r\nLinear algebra is also used in most sciences and fields of engineering, because it allows modeling many natural phenomena, and computing efficiently with such models. For nonlinear systems, which cannot be modeled with linear algebra, it is often used for dealing with first-order approximations, using the fact that the differential of a multivariate function at a point is the linear map that best approximates the function near that point. ",1,"29 Mar 2021",""),
("eeb79907b162b0fc76bae42908cbc706cb7c9f750b","BSC 010","Bachelors In Computer Science","49943644fdc0a65810f0c2f58de2ec69d0c8a9d307","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Programming Principles","70 %","30 %",3,"Offensive programming is a name used for the branch of defensive programming that expressly departs from defensive principles when dealing with errors resulting from software bugs. Although the name is a reaction to extreme interpretations of defensive programming, the two are not fundamentally in conflict. Rather, offensive programming adds an explicit priority of not tolerating errors in wrong places: the point where it departs from extreme interpretations of defensive programming is in preferring the presence of errors from within the program\'s line of defense to be blatantly obvious over the hypothetical safety benefit of tolerating them.[1][2] This preference is also what justifies using assertions.\r\n",0,"29 Mar 2021","19 Apr 2021");


DROP TABLE IF EXISTS `ezanaLMS_ModulesAnnouncements`;

CREATE TABLE `ezanaLMS_ModulesAnnouncements` (
  `id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `announcements` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `faculty_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_ModulesAnnouncements` VALUES ("477f9f6210026abfcd366631edd61d77382b5208ff","Quantum Computing 101","JOIVB34569","<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Volutpat commodo sed\r\n egestas egestas fringilla phasellus faucibus scelerisque eleifend. Sed \r\nfelis eget velit aliquet. Pharetra diam sit amet nisl suscipit \r\nadipiscing. Nisl vel pretium lectus quam id leo in. Netus et malesuada \r\nfames ac. Donec ac odio tempor orci dapibus ultrices in. A lacus \r\nvestibulum sed arcu non odio euismod lacinia. Massa sapien faucibus et \r\nmolestie ac feugiat sed. Mauris sit amet massa vitae tortor condimentum \r\nlacinia quis vel. Suspendisse ultrices gravida dictum fusce ut placerat \r\norci nulla pellentesque. Orci phasellus egestas tellus rutrum.</p>","1624528596dummy.pdf","Ezana LMS Sys Admin","2021-06-24 12:56:36","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("51977be80a6a2c23d42dfc72907e898a446444d33d","Digital Electronics 1","DICS 1010","<p>This is a module notice<br></p>","16-Jun-2021-1623844095dummy.pdf","Ezana LMS Sys Admin","2021-06-16 14:48:15","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("693402b0b390e921037279a9b174de8a25faf982e8","Object Oriented Programming","BCS 1190","Another module notice.<br>","16-Jun-2021-1623847783dummy.pdf","Mart","2021-06-16 15:49:43","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("7bb6c1cdbf013cfb0f2699e0aa4cc48074210139ce","Advanced Probability And Statistics","BICM 1051","Kindly find the attached document.<br>","15-Jun-2021-1623759146dummy.pdf","Ezana LMS Sys Admin","2021-06-15 15:12:26","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("9a74f65dc5f16b169141d96c6f3af3b4f5ad051a0b","Digital Electronics 1","DICS 1010","<p>Just another notice.<br></p>","16-Jun-2021-1623844211dummy.pdf","Ezana LMS Sys Admin","2021-06-16 14:50:11","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("b6ecb9eecb355539e716d9cd251e05e4339a68d76f","Quantum Computing 101","JOIVB34569","Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Volutpat commodo sed\r\n egestas egestas fringilla phasellus faucibus scelerisque eleifend. Sed \r\nfelis eget velit aliquet. Pharetra diam sit amet nisl suscipit \r\nadipiscing. Nisl vel pretium lectus quam id leo in. Netus et malesuada \r\nfames ac. Donec ac odio tempor orci dapibus ultrices in. A lacus \r\nvestibulum sed arcu non odio euismod lacinia. Massa sapien faucibus et \r\nmolestie ac feugiat sed. Mauris sit amet massa vitae tortor condimentum \r\nlacinia quis vel. Suspendisse ultrices gravida dictum fusce ut placerat \r\norci nulla pellentesque. Orci phasellus egestas tellus rutrum.","1624528537dummy.pdf","Ezana LMS Sys Admin","2021-06-24 12:55:37","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("d338c78e4e5d6bb682bb1bba5b18f10d271eae8941","Object Oriented Programming","BCS 1190","<p>Just another module notice.<br></p>","16-Jun-2021-1623847805dummy.pdf","Mart","2021-06-16 15:50:05","ba52fc866349d5af05addecba35600d0fd970ef7ba"),
("ec5788b6832d4f60247cd1b8b6f601806093ee9da1","Quantum Computing 101","JOIVB34569","<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod \r\ntempor incididunt ut labore et dolore magna aliqua. Volutpat commodo sed\r\n egestas egestas fringilla phasellus faucibus scelerisque eleifend. Sed \r\nfelis eget velit aliquet. Pharetra diam sit amet nisl suscipit \r\nadipiscing. Nisl vel pretium lectus quam id leo in. Netus et malesuada \r\nfames ac. Donec ac odio tempor orci dapibus ultrices in. A lacus \r\nvestibulum sed arcu non odio euismod lacinia. Massa sapien faucibus et \r\nmolestie ac feugiat sed. Mauris sit amet massa vitae tortor condimentum \r\nlacinia quis vel. Suspendisse ultrices gravida dictum fusce ut placerat \r\norci nulla pellentesque. Orci phasellus egestas tellus rutrum.</p>","1624528610dummy.pdf","Ezana LMS Sys Admin","2021-06-24 12:56:50","ba52fc866349d5af05addecba35600d0fd970ef7ba");


DROP TABLE IF EXISTS `ezanaLMS_Notifications`;

CREATE TABLE `ezanaLMS_Notifications` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `notification_detail` longblob NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_PasswordResets`;

CREATE TABLE `ezanaLMS_PasswordResets` (
  `id` varchar(200) NOT NULL,
  `token` varchar(200) NOT NULL,
  `new_pass` varchar(200) NOT NULL,
  `acc_type` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_PastPapers`;

CREATE TABLE `ezanaLMS_PastPapers` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `paper_name` varchar(200) NOT NULL,
  `pastpaper` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `solution` varchar(200) NOT NULL,
  `solution_visibility` varchar(200) NOT NULL,
  `paper_visibility` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_PastPapers` VALUES ("37b5d9e01b48452fe834f4b4f012781394051b407e","ba52fc866349d5af05addecba35600d0fd970ef7ba","Quantum Computing 101","Certificate In Quantum Computing","Quantum Computing Paper 2","1624538901dummy.pdf","2021-06-24 15:48:21","","","06/26/2021 3:48 PM"),
("4e1cd4cb15ea07b73bd955ec68278d3fedba9d63e8","ba52fc866349d5af05addecba35600d0fd970ef7ba","Digital Electronics 1","Diploma In Computer Science","Digital Electronics 1","16-Jun-2021-1623844380dummy.pdf","2021-06-16 14:55:06","16-Jun-2021-1623844506dummy.pdf","Available","Hidden"),
("9a3290964ba235d05719c9d413bddec52f07d862f0","ba52fc866349d5af05addecba35600d0fd970ef7ba","Advanced Probability And Statistics","Bachelors In Computational Mathematics","Advanced Probability And Statistics","15-Jun-2021-1623759491dummy.pdf","2021-06-15 15:18:29","15-Jun-2021-1623759509dummy.pdf","Available","Available"),
("a11a70623a5cd24441c682e3170ce79a061b5103dd","ba52fc866349d5af05addecba35600d0fd970ef7ba","Quantum Computing 101","Certificate In Quantum Computing","Quantum Computing Final Exam","1624535661dummy.pdf","2021-06-24 15:46:39","1624537266dummy.pdf","06/30/2021 1:50 AM","06/24/2021 2:50 AM"),
("c7882ca3a96862c468ed6f0f6dfa88f6c49ea4b181","ba52fc866349d5af05addecba35600d0fd970ef7ba","Object Oriented Programming","Bachelors In Computer Science","Object Oriented Programming","16-Jun-2021-1623848047dummy.pdf","2021-06-16 15:54:14","16-Jun-2021-1623848054dummy.pdf","Available","Available"),
("cf1b7096e63482f61df77e3b24277b5554c932d108","ba52fc866349d5af05addecba35600d0fd970ef7ba","Quantum Computing 101","Certificate In Quantum Computing","Quantum Computing Paper 2","1624537637dummy.pdf","2021-06-24 15:33:26","1624538006dummy.pdf","06/30/2021 3:33 PM","06/24/2021 3:27 PM"),
("db04d7eff3ba4f8d8ed3f5bd521a8f3c4c6d695de4","ba52fc866349d5af05addecba35600d0fd970ef7ba","Digital Electronics 1","Diploma In Computer Science","Digital Electronics 1","16-Jun-2021-1623844294dummy.pdf","2021-06-16 14:51:49","16-Jun-2021-1623844309dummy.pdf","Available","Available"),
("f363c910c6a23ab68c6d2a67f9fd60d4f60ed2c0a1","ba52fc866349d5af05addecba35600d0fd970ef7ba","Object Oriented Programming","Bachelors In Computer Science","Object Oriented Programming","16-Jun-2021-1623848004dummy.pdf","2021-06-16 15:53:39","16-Jun-2021-1623848019dummy.pdf","Available","Available");


DROP TABLE IF EXISTS `ezanaLMS_Settings`;

CREATE TABLE `ezanaLMS_Settings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `sysname` longtext NOT NULL,
  `logo` longtext NOT NULL,
  `version` varchar(200) NOT NULL,
  `policy` blob NOT NULL,
  `calendar_iframe` longblob NOT NULL,
  `stmp_host` varchar(200) NOT NULL,
  `stmp_port` varchar(200) NOT NULL,
  `stmp_sent_from` varchar(200) NOT NULL,
  `stmp_username` varchar(200) NOT NULL,
  `stmp_password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Settings` VALUES (1,"Ezana","logo.png","1.3.0 Beta","","<iframe src=\"https://calendar.google.com/calendar/embed?height=600&wkst=1&bgcolor=%23ffffff&ctz=Africa%2FNairobi&src=NzZlcnNzdWs4MzJmZDU3dTc1cXIzMzJ1OWdAZ3JvdXAuY2FsZW5kYXIuZ29vZ2xlLmNvbQ&src=ZW4ua2UjaG9saWRheUBncm91cC52LmNhbGVuZGFyLmdvb2dsZS5jb20&color=%23E4C441&color=%230B8043&showTitle=0&showTz=0\" style=\"border-width:0\" width=\"1050\" height=\"600\" frameborder=\"0\" scrolling=\"no\" ></iframe>","smtp.gmail.com",465,"devlaninc18@gmail.com","devlaninc18@gmail.com","20Devlan@");


DROP TABLE IF EXISTS `ezanaLMS_StudentAnswers`;

CREATE TABLE `ezanaLMS_StudentAnswers` (
  `id` varchar(200) NOT NULL,
  `exam_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `attachments` varchar(200) NOT NULL,
  `student_regno` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_StudentGrades`;

CREATE TABLE `ezanaLMS_StudentGrades` (
  `id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `student_regno` varchar(200) NOT NULL,
  `marks_attained` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_StudentModuleGrades`;

CREATE TABLE `ezanaLMS_StudentModuleGrades` (
  `id` varchar(200) NOT NULL,
  `regno` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `assignment_name` varchar(200) NOT NULL,
  `marks` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `academic_year` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_StudentModuleGrades` VALUES ("8caabc873fc3082f7e74d7531a2e5ce5f92abeafa9","PZTFY90651","MartMbithi","JOIVB34569","Quantum Computing 101","Assignment 1",90,"Jan - Apr ","Sep 2020 - Sep 2021 ","02abafc898bc2b993cc646fff7fd94078442f33c1c");


DROP TABLE IF EXISTS `ezanaLMS_Students`;

CREATE TABLE `ezanaLMS_Students` (
  `id` varchar(200) NOT NULL,
  `admno` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `adr` varchar(200) NOT NULL,
  `dob` varchar(200) NOT NULL,
  `idno` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `acc_status` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `day_enrolled` varchar(200) NOT NULL,
  `school` varchar(200) NOT NULL,
  `course` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `current_year` varchar(200) NOT NULL,
  `no_of_modules` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Students` VALUES ("06b743f583258e4a8235e517a9627d2d5c7b5c69","BSCMKS275517","Mart","martinezmbithi@gmail.com","9ead470d4cba74e63dbcd0e5454afc7fe9037614",2547100100901,"90126 Localhost","2021-06-23",90010009,"Male","Active","22 Jun 2021","23 Jun 2021","1624362772_DSC9753.JPG","ba52fc866349d5af05addecba35600d0fd970ef7ba","12/12/20","School Of Computing Sciences","Bachelors In Computational Mathematics","Computational Science And Mathematics","1st Year",""),
("160302d4b6f265e34029c05d361396de4dd0f3c4","BSCMKS275519","Mbithi","martdevelopers254@gmail.com","9156a2ee670e934e74d188e1dc8fb551a19c189f",2547109099090,"90127 Localhost","12-12-1991",90010010,"Male","Active","22 Jun 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","12/12/20","School Of Computing Sciences","Bachelors In Computational Mathematics","Computational Science And Mathematics","1st Year",""),
("7249e59080bfb06c6b35bcf22904d9a52ae72d2cf2","PZTFY90651","MartMbithi","martinezmbithi@gmail.com","94bb9da578ada3b32cf16a2e3fa0488071ab2a04",07171717199,"90126 Localhost","2021-06-21",90100100,"Female","Active","21 Jun 2021","22 Jun 2021","","ba52fc866349d5af05addecba35600d0fd970ef7ba","2021-06-21","School Of Computing Sciences","Diploma In Computer Science","Computer Science","1st Year",""),
("a492e8e6388ff4a89fc7c3cb873076335271d9473b","QRXDG76819","Martin","martdevelopers254@gmail.com","b5e9ecc5d5124b708e0d33c7db8eec0596c323df",07200200299,"90100 Localhost","12-12-1990",90100765,"Male","Active","22 Jun 2021","","1624359795desktop-grub.png","ba52fc866349d5af05addecba35600d0fd970ef7ba","2021-06-22","School Of Computing Sciences","Bachelors In Computational Mathematics","Computational Science And Mathematics","1st Year","");


DROP TABLE IF EXISTS `ezanaLMS_StudentsGroups`;

CREATE TABLE `ezanaLMS_StudentsGroups` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `student_admn` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_StudentsGroups` VALUES ("1c13f8b3b5b96e53570f3bf68ca3eee0cc91d1ab3b","ba52fc866349d5af05addecba35600d0fd970ef7ba","Group Beta","TPIRJ13872","PZTFY90651","MartMbithi","2021-06-25 10:44:59"),
("25dcc08f692fa5ab13d72290d2d2c3845b00550d10","ba52fc866349d5af05addecba35600d0fd970ef7ba","Alpha Group","GIMSC01274","EZANALMS002","Mart Mbithi","2021-06-16 16:01:12"),
("a9988f1015f7f9900f40aeddeab7cbebb9e4222bd3","ba52fc866349d5af05addecba35600d0fd970ef7ba","Group Alpha","BUXQG02571","TDWXG74012","martin","2021-06-15 15:34:03");


DROP TABLE IF EXISTS `ezanaLMS_TimeTable`;

CREATE TABLE `ezanaLMS_TimeTable` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `course_code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lecturer` varchar(200) NOT NULL,
  `day` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `room` varchar(200) NOT NULL,
  `link` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_TimeTable` VALUES ("45058635de8a61bf7d5689f93d9106c54b963da72d","ba52fc866349d5af05addecba35600d0fd970ef7ba","BCM","Bachelors In Computational Mathematics","BICM 101","Linear Algebra","Mart Developers","Sunday","12:00PM - 03:30PM","Room 1",""),
("5b572e97c06efc36cb3fac7396185733f2082540b3","ba52fc866349d5af05addecba35600d0fd970ef7ba","DICS","Diploma In Computer Science","DICS 1010","Digital Electronics 1","Lecturer 0001","Monday","12:00 Noon - 03 : 00 PM","R 18",""),
("62ce0b1f735fa3c1630771299229304cd155c82d91","ba52fc866349d5af05addecba35600d0fd970ef7ba","BCM","Bachelors In Computational Mathematics","BICM 101","Linear Algebra","Lecturer 0001","Tuesday","12:00 Noon - 03 : 00 PM","Room 7","");


DROP TABLE IF EXISTS `ezanaLMS_UserLog`;

CREATE TABLE `ezanaLMS_UserLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(200) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `loginTime` varchar(200) NOT NULL,
  `exact_login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `User_Rank` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_UserLog` VALUES (3,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-21","2021-06-21 11:50:12","Administrator"),
(4,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-22","2021-06-22 10:44:36","Administrator"),
(5,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-22","2021-06-22 14:53:31","Administrator"),
(6,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-23","2021-06-23 10:57:34","Administrator"),
(7,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-24","2021-06-24 10:57:09","Administrator"),
(8,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-25","2021-06-25 09:49:14","Administrator"),
(9,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-26","2021-06-26 11:49:07","Administrator"),
(10,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-26","2021-06-26 14:47:24","Administrator"),
(11,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-27","2021-06-27 09:39:10","Administrator"),
(12,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-28","2021-06-28 17:43:09","Administrator"),
(13,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-06-28","2021-06-28 19:46:37","Administrator");


DROP TABLE IF EXISTS `ezanaLMS_UserRequests`;

CREATE TABLE `ezanaLMS_UserRequests` (
  `id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `request` longtext NOT NULL,
  `progress` longtext NOT NULL,
  `status` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_UserRequests` VALUES ("2d6fd87c8e4737fd670fdc0cbd565684","martin","martdevelopers254@gmail.com","TDWXG74012"," This tool generates random MD5 digests in your browser. It has several nifty configuration options that let you set how many MD5 checksums you need, configure a custom MD5 format, choose output base, and change MD5 case to upper case, lower case or random case. The MD5 message digest algorithm was invented by MIT professor Ronald Rivest in 1992 and it produces 128-bit hash values. In hex encoding, 128 bits are represented as 32 hex characters (each hex character is 4 bits). The custom MD5 format option allows you to enter wildcard format that the MD5 hashes will follow. For example, to generate MD5s that start with a zero and end with a one, you can enter \"0*1\" in the format field. The special character \"?\" means any hex digit. For example, \"abc???000*\" will generate a hash that starts with \"abc\", followed by any three hex digits, followed by three zeros, and then followed by random characters. After MD5s are generated, you can convert them to a custom base. We support binary, octal, decimal, octal, hex (default) predefined bases and also custom bases from 2 to 36. Hashabulous! ",100,"Approved","2021-06-21 14:17:42");


SET foreign_key_checks = 1;
