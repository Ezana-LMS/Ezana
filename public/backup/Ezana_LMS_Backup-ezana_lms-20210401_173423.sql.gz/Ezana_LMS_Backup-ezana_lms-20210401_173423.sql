CREATE DATABASE IF NOT EXISTS `ezana_lms`;

USE `ezana_lms`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `clean_name` varchar(45) NOT NULL,
  `description` text,
  `nextVideoOrder` int(2) NOT NULL DEFAULT '0',
  `parentId` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `iconClass` varchar(45) NOT NULL DEFAULT 'fa fa-folder',
  `users_id` int(11) NOT NULL DEFAULT '1',
  `private` tinyint(1) DEFAULT '0',
  `allow_download` tinyint(1) DEFAULT '1',
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clean_name_UNIQUE` (`clean_name`),
  KEY `fk_categories_users1_idx` (`users_id`),
  KEY `clean_name_INDEX2` (`clean_name`),
  KEY `sortcategoryOrderIndex` (`order`),
  KEY `category_name_idx` (`name`),
  FULLTEXT KEY `index7cname` (`name`),
  FULLTEXT KEY `index8cdescr` (`description`),
  CONSTRAINT `fk_categories_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `categories` VALUES (1,"Default","default","",0,0,"2021-03-26 21:38:38","2021-03-26 21:38:38","fa fa-folder",1,0,1,NULL);


DROP TABLE IF EXISTS `categories_has_users_groups`;

CREATE TABLE `categories_has_users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) NOT NULL,
  `users_groups_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  PRIMARY KEY (`id`),
  KEY `fk_categories_has_users_groups_users_groups1_idx` (`users_groups_id`),
  KEY `fk_categories_has_users_groups_categories1_idx` (`categories_id`),
  CONSTRAINT `fk_categories_has_users_groups_categories1` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_categories_has_users_groups_users_groups1` FOREIGN KEY (`users_groups_id`) REFERENCES `users_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `category_type_cache`;

CREATE TABLE `category_type_cache` (
  `categoryId` int(11) NOT NULL,
  `type` int(2) NOT NULL DEFAULT '0' COMMENT '0=both, 1=audio, 2=video',
  `manualSet` int(1) NOT NULL DEFAULT '0' COMMENT '0=auto, 1=manual',
  UNIQUE KEY `categoryId` (`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `videos_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `comments_id_pai` int(11) DEFAULT NULL,
  `pin` int(1) NOT NULL DEFAULT '0' COMMENT 'If = 1 will be on the top',
  PRIMARY KEY (`id`),
  KEY `fk_comments_videos1_idx` (`videos_id`),
  KEY `fk_comments_users1_idx` (`users_id`),
  KEY `fk_comments_comments1_idx` (`comments_id_pai`),
  CONSTRAINT `fk_comments_comments1` FOREIGN KEY (`comments_id_pai`) REFERENCES `comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comments_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comments_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `comments_likes`;

CREATE TABLE `comments_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `like` int(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `comments_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_likes_users1_idx` (`users_id`),
  KEY `fk_comments_likes_comments1_idx` (`comments_id`),
  CONSTRAINT `fk_comments_likes_comments1` FOREIGN KEY (`comments_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comments_likes_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `configurations`;

CREATE TABLE `configurations` (
  `id` int(11) NOT NULL,
  `video_resolution` varchar(12) NOT NULL,
  `users_id` int(11) NOT NULL,
  `version` varchar(10) NOT NULL,
  `webSiteTitle` varchar(45) NOT NULL DEFAULT 'AVideo',
  `language` varchar(6) NOT NULL DEFAULT 'en',
  `contactEmail` varchar(254) NOT NULL,
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  `authGoogle_id` varchar(255) DEFAULT NULL,
  `authGoogle_key` varchar(255) DEFAULT NULL,
  `authGoogle_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `authFacebook_id` varchar(255) DEFAULT NULL,
  `authFacebook_key` varchar(255) DEFAULT NULL,
  `authFacebook_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `authCanUploadVideos` tinyint(1) NOT NULL DEFAULT '0',
  `authCanViewChart` tinyint(2) NOT NULL DEFAULT '0',
  `authCanComment` tinyint(1) NOT NULL DEFAULT '1',
  `head` text,
  `logo` varchar(255) DEFAULT NULL,
  `logo_small` varchar(255) DEFAULT NULL,
  `adsense` text,
  `mode` enum('Youtube','Gallery') DEFAULT 'Youtube',
  `disable_analytics` tinyint(1) DEFAULT '0',
  `disable_youtubeupload` tinyint(1) DEFAULT '0',
  `allow_download` tinyint(1) DEFAULT '0',
  `session_timeout` int(11) DEFAULT '3600',
  `autoplay` tinyint(1) DEFAULT NULL,
  `theme` varchar(45) DEFAULT 'default',
  `smtp` tinyint(1) DEFAULT NULL,
  `smtpAuth` tinyint(1) DEFAULT NULL,
  `smtpSecure` varchar(255) DEFAULT NULL COMMENT '''ssl''; // secure transfer enabled REQUIRED for Gmail',
  `smtpHost` varchar(255) DEFAULT NULL COMMENT '"smtp.gmail.com"',
  `smtpUsername` varchar(255) DEFAULT NULL COMMENT '"email@gmail.com"',
  `smtpPassword` varchar(255) DEFAULT NULL,
  `smtpPort` int(11) DEFAULT NULL,
  `encoderURL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_configurations_users1_idx` (`users_id`),
  CONSTRAINT `fk_configurations_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `configurations` VALUES (1,"858:480",1,"10.5","EzanaLMS","us","martinezmbithi@gmail.com","2021-03-26 21:38:38","2021-03-26 21:38:38",NULL,NULL,0,NULL,NULL,0,0,0,1,NULL,NULL,NULL,NULL,"Youtube",0,0,0,3600,NULL,"default",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"https://encoder1.avideo.com/");


DROP TABLE IF EXISTS `ezanaLMS_AcademicSettings`;

CREATE TABLE `ezanaLMS_AcademicSettings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `current_academic_year` varchar(200) NOT NULL,
  `current_semester` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_AcademicSettings` VALUES (1,"Sep 2020 - Sep 2021 ","Jan - Apr ","Current","2021-01-04","2021-04-17");


DROP TABLE IF EXISTS `ezanaLMS_Admins`;

CREATE TABLE `ezanaLMS_Admins` (
  `id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `phone` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `date_employed` varchar(200) NOT NULL,
  `school` varchar(200) NOT NULL,
  `adr` varchar(200) NOT NULL,
  `previledge` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Admins` VALUES ("3abf1651a3e361db3af99a25810703b4ce75957c","Educational Administrator","martinezmbithi@gmail.com","a69681bcf334ae130217fea4505fd3c994f5683f","Education Administrator","2021-03-31 12:17:32.459286","+25472789053","Male","90-126","12-02-2020","School Of Computer Science","127001 Localhost","View","devlan.jpg",""),
("a69681bcf334ae130217fea4505fd3c994f5683f","Ezana LMS Sys Admin","sysadmin@ezana.org","adcd7048512e64b48da55b027577886ee5a36350","System Administrator","2021-03-25 16:15:00.175463","+90127690-90","Male","90-126","","School Of Computer Science","129 - 90 127 Localhost","Edit And Delete","logo.png",""),
("ded73cec16f145e5f5c3415caa15ce76b506508147","Jane Doe","janedoe@ezana.org","75041af0ad7a078a3b9381ae1f77ba29060cd0ce","Education Administrator","2021-03-25 15:34:39.552134","+90-1270914000","Female","90127-92","","School Of Computer Science","127 Localhost","Edit And Delete","devlan.jpg","");


DROP TABLE IF EXISTS `ezanaLMS_AssignmentsAttempts`;

CREATE TABLE `ezanaLMS_AssignmentsAttempts` (
  `id` varchar(200) NOT NULL,
  `assignment_id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `std_name` varchar(200) NOT NULL,
  `std_regno` varchar(200) NOT NULL,
  `attachments` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_Calendar`;

CREATE TABLE `ezanaLMS_Calendar` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `academic_yr` varchar(200) NOT NULL,
  `semester_name` varchar(200) NOT NULL,
  `semester_start` varchar(200) NOT NULL,
  `semester_end` varchar(200) NOT NULL,
  `description` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Calendar` VALUES ("d2c4b201ecbf33627bfe50ad572a1d8994cdcc2dd4","ba52fc866349d5af05addecba35600d0fd970ef7ba","Sep 2020 - Sep 2021 ","Jan - Apr ","2021-04-12","2021-04-17","Faculty Exam week");


DROP TABLE IF EXISTS `ezanaLMS_ClassRecordings`;

CREATE TABLE `ezanaLMS_ClassRecordings` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `class_name` varchar(200) NOT NULL,
  `lecturer_name` varchar(200) NOT NULL,
  `external_link` varchar(200) NOT NULL,
  `video` longtext NOT NULL,
  `details` longblob NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_CourseDirectories`;

CREATE TABLE `ezanaLMS_CourseDirectories` (
  `id` varchar(200) NOT NULL,
  `course_code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_materials` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_CourseMemo`;

CREATE TABLE `ezanaLMS_CourseMemo` (
  `id` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_memo` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `faculty_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_Courses`;

CREATE TABLE `ezanaLMS_Courses` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `faculty_name` varchar(200) NOT NULL,
  `department_id` varchar(200) NOT NULL,
  `department_name` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `hod` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Courses` VALUES ("49943644fdc0a65810f0c2f58de2ec69d0c8a9d307","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","e8ba39cec3ef9f1842be2b46f65aa7fca0737e674e","Computer Science","BCS","Bachelors In Computer Science","Mr James Holden","jamesholden@bcs.ezana.org","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. "),
("78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","801b96f782310aa15ae942e6e6dd6fea0ec8fc0f57","Computational Science And Mathematics","BCM","Bachelors In Computational Mathematics","Mrs Hanna Montana","hannamont@bcm.ezana.org","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. "),
("83dccbf9942bbada9ce4696f6a075e51e98b4de662","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","801b96f782310aa15ae942e6e6dd6fea0ec8fc0f57","Computational Science And Mathematics","DICM","Diploma In Computational Mathematics","Mrs Jane F Doe","janedoe@dicm.ezana.org","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. "),
("9bd615c255bc533378e946171d9b8fa61980605a70","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","e8ba39cec3ef9f1842be2b46f65aa7fca0737e674e","Computer Science","DICS","Diploma In Computer Science","","","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. ");


DROP TABLE IF EXISTS `ezanaLMS_DepartmentalMemos`;

CREATE TABLE `ezanaLMS_DepartmentalMemos` (
  `id` varchar(200) NOT NULL,
  `department_id` varchar(200) NOT NULL,
  `department_name` varchar(200) NOT NULL,
  `departmental_memo` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_Departments`;

CREATE TABLE `ezanaLMS_Departments` (
  `id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `faculty_name` varchar(200) NOT NULL,
  `hod` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Departments` VALUES ("0c375c729c2f1c57e4d118ba50b0c3063fcda4c704","CI","Computational Intelligence ","ba52fc866349d5af05addecba35600d0fd970ef7ba","","Mr James Holden","Computational Intelligence (CI) is the theory, design, application and development of biologically and linguistically motivated computational paradigms. Traditionally the three main pillars of CI have been Neural Networks, Fuzzy Systems and Evolutionary Computation.","31 Mar 2021"),
("801b96f782310aa15ae942e6e6dd6fea0ec8fc0f57","MRXQP81349","Computational Science And Mathematics","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","Mr James Holden","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. ","29 Mar 2021"),
("e8ba39cec3ef9f1842be2b46f65aa7fca0737e674e","RUWKI08562","Computer Science","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","Mrs Hanna Montana","Computer science is the study of algorithmic processes, computational machines and computation itself.[1] As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.[2][3]\r\n\r\nIts fields can be divided into theoretical and practical disciplines. For example, the theory of computation concerns abstract models of computation and general classes of problems that can be solved using them, while computer graphics or computational geometry emphasize more specific applications. Algorithms and data structures have been called the heart of computer science.[4] Programming language theory considers approaches to the description of computational processes, while computer programming involves the use of them to create complex systems. Computer architecture describes construction of computer components and computer-operated equipment. Artificial intelligence aims to synthesize goal-orientated processes such as problem-solving, decision-making, environmental adaptation, planning and learning found in humans and animals. A digital computer is capable of simulating various information processes.[5] The fundamental concern of computer science is determining what can and cannot be automated.[6] Computer scientists usually focus on academic research. The Turing Award is generally recognized as the highest distinction in computer sciences. ","29 Mar 2021");


DROP TABLE IF EXISTS `ezanaLMS_Enrollments`;

CREATE TABLE `ezanaLMS_Enrollments` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `student_adm` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `semester_enrolled` varchar(200) NOT NULL,
  `course_code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `semester_start` varchar(200) NOT NULL,
  `semester_end` varchar(200) NOT NULL,
  `academic_year_enrolled` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Enrollments` VALUES ("0fdabb42c39899613897e1a5965a1d37fbbd49b1ef","ba52fc866349d5af05addecba35600d0fd970ef7ba","BZQAH87625","XBNYV13094","Student 003","Jan - Apr ","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Basic Calculus","BICM 102","01 Apr 2021",""),
("35d75693343ccc212ef3849ea3c94d54047657e192","ba52fc866349d5af05addecba35600d0fd970ef7ba","GHQNO85271","XBNYV13090","Student 001","Jan - Apr ","BCS","Bachelors In Computer Science","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Programming Principles","BSC 010","31 Mar 2021",""),
("72722b2c46e7bf0c3c6856ba1e0e10fd6145d6895e","ba52fc866349d5af05addecba35600d0fd970ef7ba","JLMDX17804","XBNYV13093","Student 002","Jan - Apr ","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Basic Calculus","BICM 102","01 Apr 2021",""),
("9124a94bea0c4769cb9f4b73cf69811cbd092868b2","ba52fc866349d5af05addecba35600d0fd970ef7ba","SHNZL98175","XBNYV13090","Student 001","Jan - Apr ","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Basic Calculus","BICM 102","01 Apr 2021",""),
("92aed4b368e452628e2810bbeffcbb43e0f0924bc9","ba52fc866349d5af05addecba35600d0fd970ef7ba","SKVRC80952","XBNYV13097","Student 006","Jan - Apr ","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Basic Calculus","BICM 102","01 Apr 2021",""),
("a6eb37ac28ba7873bf0bd651368e19c26a9d14f683","ba52fc866349d5af05addecba35600d0fd970ef7ba","FXCEB94017","XBNYV13093","Student 002","Jan - Apr ","BCS","Bachelors In Computer Science","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Programming Principles","BSC 010","31 Mar 2021",""),
("a78132227c7e6fefbc3ebca3b44448f42d01ed9379","ba52fc866349d5af05addecba35600d0fd970ef7ba","CNVMU94610","XBNYV13090","Student 001","Jan - Apr ","BCS","Bachelors In Computer Science","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Object Oriented Programming","BCS 1190","31 Mar 2021",""),
("cc5a5c16ea0ebf8ebf97e2326b68472925f9e0aa3f","ba52fc866349d5af05addecba35600d0fd970ef7ba","OHNJY63812","XBNYV13094","Student 003","Jan - Apr ","BCS","Bachelors In Computer Science","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Programming Principles","BSC 010","31 Mar 2021",""),
("d4d5e27834c848e06aa134863822e6d78e8e18b415","ba52fc866349d5af05addecba35600d0fd970ef7ba","AOQNX42096","XBNYV13095","Student 004","Jan - Apr ","BCS","Bachelors In Computer Science","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Programming Principles","BSC 010","31 Mar 2021",""),
("d8aa8c7fb82fb7f9a2e6d5667be9dc8a530a23b701","ba52fc866349d5af05addecba35600d0fd970ef7ba","MILKQ74582","XBNYV13095","Student 004","Jan - Apr ","BCS","Bachelors In Computer Science","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Object Oriented Programming","BCS 1190","31 Mar 2021",""),
("e011c722965306817d6513709dca0f3dd382e8539a","ba52fc866349d5af05addecba35600d0fd970ef7ba","APXYC25678","XBNYV13095","Student 004","Jan - Apr ","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Basic Calculus","BICM 102","01 Apr 2021",""),
("e485d2dd9b350f1f30c1bdfdf8bad8d3d042a4c2cb","ba52fc866349d5af05addecba35600d0fd970ef7ba","ILBQF25039","XBNYV13096","Student 005","Jan - Apr ","BCM","Bachelors In Computational Mathematics","2021-01-04","2021-04-17","Sep 2020 - Sep 2021 ","Basic Calculus","BICM 102","01 Apr 2021","");


DROP TABLE IF EXISTS `ezanaLMS_Events`;

CREATE TABLE `ezanaLMS_Events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_ExamQuestions`;

CREATE TABLE `ezanaLMS_ExamQuestions` (
  `id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `exam_time` varchar(200) NOT NULL,
  `instructions` longtext NOT NULL,
  `attachment` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_Faculties`;

CREATE TABLE `ezanaLMS_Faculties` (
  `id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `head` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Faculties` VALUES ("4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","YBJTD96340","School Of Business And Management Studies","Mr Johnes Doe","johnes@businessschool.ezana.org","Computer science is the study of algorithmic processes, computational machines and computation itself. As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software. "),
("ba52fc866349d5af05addecba35600d0fd970ef7ba","KFQMH38140","School Of Computing Sciences","Mr James Doe","jamesdoe@computingsciences.org","Computer science is the study of algorithmic processes, computational machines and computation itself. As a discipline, computer science spans a range of topics from theoretical studies of algorithms, computation and information to the practical issues of implementing computational systems in hardware and software.");


DROP TABLE IF EXISTS `ezanaLMS_Groups`;

CREATE TABLE `ezanaLMS_Groups` (
  `id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Groups` VALUES ("18473e43ab4ba3fe038863253aa7e6d18899f59815","b64d04da5331ebd753398d7c73ad69958048d5d9fe","ba52fc866349d5af05addecba35600d0fd970ef7ba","JMKHF96831","Group 001","This is group one","2021-04-01 18:22:37","");


DROP TABLE IF EXISTS `ezanaLMS_GroupsAnnouncements`;

CREATE TABLE `ezanaLMS_GroupsAnnouncements` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `group_code` varchar(200) NOT NULL,
  `group_name` varchar(200) NOT NULL,
  `announcement` longblob NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_GroupsAssignments`;

CREATE TABLE `ezanaLMS_GroupsAssignments` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `group_code` varchar(200) NOT NULL,
  `group_name` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `submitted_on` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_GroupsAssignmentsGrades`;

CREATE TABLE `ezanaLMS_GroupsAssignmentsGrades` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `group_name` varchar(200) NOT NULL,
  `group_code` varchar(200) NOT NULL,
  `project_id` varchar(200) NOT NULL,
  `Submitted_Files` longtext NOT NULL,
  `group_score` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_Lecturers`;

CREATE TABLE `ezanaLMS_Lecturers` (
  `id` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `idno` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `adr` longtext NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `faculty_name` varchar(200) NOT NULL,
  `work_email` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `date_employed` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Lecturers` VALUES ("1258ce18b72f8a2f0e8b4f88813ca77d93988050","Ezana-SCSS-001","Lecturer 0001",127000,7023089509,"Lecturer0001@ezana.001","127- Localhost","a69681bcf334ae130217fea4505fd3c994f5683f","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.001","Male",21899,"12-02-1950","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988051","Ezana-SCSS-002","Lecturer 0002",127001,7023089510,"Lecturer0001@ezana.002","128- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.002","Male",21900,"12-02-1951","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988052","Ezana-SCSS-003","Lecturer 0003",127002,7023089511,"Lecturer0001@ezana.003","129- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.003","Male",21901,"12-02-1952","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988053","Ezana-SCSS-004","Lecturer 0004",127003,7023089512,"Lecturer0001@ezana.004","130- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.004","Male",21902,"12-02-1953","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988054","Ezana-SCSS-005","Lecturer 0005",127004,7023089513,"Lecturer0001@ezana.005","131- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.005","Male",21903,"12-02-1954","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988055","Ezana-SCSS-006","Lecturer 0006",127005,7023089514,"Lecturer0001@ezana.006","132- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.006","Male",21904,"12-02-1955","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988056","Ezana-SCSS-007","Lecturer 0007",127006,7023089515,"Lecturer0001@ezana.007","133- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.007","Male",21905,"12-02-1956","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988057","Ezana-SCSS-008","Lecturer 0008",127007,7023089516,"Lecturer0001@ezana.008","134- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.008","Male",21906,"12-02-1957","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988058","Ezana-SCSS-009","Lecturer 0009",127008,7023089517,"Lecturer0001@ezana.009","135- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.009","Male",21907,"12-02-1958","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988059","Ezana-SCSS-010","Lecturer 0010",127009,7023089518,"Lecturer0001@ezana.010","136- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.010","Male",21908,"12-02-1959","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988060","Ezana-SCSS-011","Lecturer 0011",127010,7023089519,"Lecturer0001@ezana.011","137- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.011","Male",21909,"12-02-1960","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988061","Ezana-SCSS-012","Lecturer 0012",127011,7023089520,"Lecturer0001@ezana.012","138- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.012","Male",21910,"12-02-1961","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988062","Ezana-SCSS-013","Lecturer 0013",127012,7023089521,"Lecturer0001@ezana.013","139- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.013","Male",21911,"12-02-1962","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988063","Ezana-SCSS-014","Lecturer 0014",127013,7023089522,"Lecturer0001@ezana.014","140- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.014","Male",21912,"12-02-1963","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988064","Ezana-SCSS-015","Lecturer 0015",127014,7023089523,"Lecturer0001@ezana.015","141- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.015","Male",21913,"12-02-1964","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988065","Ezana-SCSS-016","Lecturer 0016",127015,7023089524,"Lecturer0001@ezana.016","142- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.016","Male",21914,"12-02-1965","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988066","Ezana-SCSS-017","Lecturer 0017",127016,7023089525,"Lecturer0001@ezana.017","143- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.017","Male",21915,"12-02-1966","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988067","Ezana-SCSS-018","Lecturer 0018",127017,7023089526,"Lecturer0001@ezana.018","144- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.018","Male",21916,"12-02-1967","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988068","Ezana-SCSS-019","Lecturer 0019",127018,7023089527,"Lecturer0001@ezana.019","145- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.019","Male",21917,"12-02-1968","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988069","Ezana-SCSS-020","Lecturer 0020",127019,7023089528,"Lecturer0001@ezana.020","146- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.020","Male",21918,"12-02-1969","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988070","Ezana-SCSS-021","Lecturer 0021",127020,7023089529,"Lecturer0001@ezana.021","147- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.021","Male",21919,"12-02-1970","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988071","Ezana-SCSS-022","Lecturer 0022",127021,7023089530,"Lecturer0001@ezana.022","148- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.022","Male",21920,"12-02-1971","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988072","Ezana-SCSS-023","Lecturer 0023",127022,7023089531,"Lecturer0001@ezana.023","149- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.023","Male",21921,"12-02-1972","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988073","Ezana-SCSS-024","Lecturer 0024",127023,7023089532,"Lecturer0001@ezana.024","150- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.024","Male",21922,"12-02-1973","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988074","Ezana-SCSS-025","Lecturer 0025",127024,7023089533,"Lecturer0001@ezana.025","151- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.025","Female",21923,"12-02-1974","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988075","Ezana-SCSS-026","Lecturer 0026",127025,7023089534,"Lecturer0001@ezana.026","152- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.026","Female",21924,"12-02-1975","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988076","Ezana-SCSS-027","Lecturer 0027",127026,7023089535,"Lecturer0001@ezana.027","153- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.027","Female",21925,"12-02-1976","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988077","Ezana-SCSS-028","Lecturer 0028",127027,7023089536,"Lecturer0001@ezana.028","154- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.028","Female",21926,"12-02-1977","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988078","Ezana-SCSS-029","Lecturer 0029",127028,7023089537,"Lecturer0001@ezana.029","155- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.029","Female",21927,"12-02-1978","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988079","Ezana-SCSS-030","Lecturer 0030",127029,7023089538,"Lecturer0001@ezana.030","156- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","ba52fc866349d5af05addecba35600d0fd970ef7ba","School Of Computing Sciences","ezana-SCSS-001@ezana.030","Female",21928,"12-02-1979","On Leave"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988080","Ezana-BMS-031","Lecturer 0031",355748,7023089539,"Lecturer@ezana.031","156- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.031","Female",21929,"12-02-1979","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988081","Ezana-BMS-032","Lecturer 0032",355749,7023089540,"Lecturer@ezana.032","157- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.032","Female",21930,"12-02-1980","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988082","Ezana-BMS-033","Lecturer 0033",355750,7023089541,"Lecturer@ezana.033","158- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.033","Female",21931,"12-02-1981","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988083","Ezana-BMS-034","Lecturer 0034",355751,7023089542,"Lecturer@ezana.034","159- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.034","Female",21932,"12-02-1982","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988084","Ezana-BMS-035","Lecturer 0035",355752,7023089543,"Lecturer@ezana.035","160- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.035","Female",21933,"12-02-1983","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988085","Ezana-BMS-036","Lecturer 0036",355753,7023089544,"Lecturer@ezana.036","161- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.036","Female",21934,"12-02-1984","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988086","Ezana-BMS-037","Lecturer 0037",355754,7023089545,"Lecturer@ezana.037","162- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.037","Female",21935,"12-02-1985","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988087","Ezana-BMS-038","Lecturer 0038",355755,7023089546,"Lecturer@ezana.038","163- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.038","Female",21936,"12-02-1986","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988088","Ezana-BMS-039","Lecturer 0039",355756,7023089547,"Lecturer@ezana.039","164- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.039","Female",21937,"12-02-1987","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988089","Ezana-BMS-040","Lecturer 0040",355757,7023089548,"Lecturer@ezana.040","165- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.040","Female",21938,"12-02-1988","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988090","Ezana-BMS-041","Lecturer 0041",355758,7023089549,"Lecturer@ezana.041","166- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.041","Female",21939,"12-02-1989","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988091","Ezana-BMS-042","Lecturer 0042",355759,7023089550,"Lecturer@ezana.042","167- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.042","Female",21940,"12-02-1990","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988092","Ezana-BMS-043","Lecturer 0043",355760,7023089551,"Lecturer@ezana.043","168- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.043","Female",21941,"12-02-1991","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988093","Ezana-BMS-044","Lecturer 0044",355761,7023089552,"Lecturer@ezana.044","169- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.044","Female",21942,"12-02-1992","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988094","Ezana-BMS-045","Lecturer 0045",355762,7023089553,"Lecturer@ezana.045","170- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.045","Female",21943,"12-02-1993","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988095","Ezana-BMS-046","Lecturer 0046",355763,7023089554,"Lecturer@ezana.046","171- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.046","Female",21944,"12-02-1994","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988096","Ezana-BMS-047","Lecturer 0047",355764,7023089555,"Lecturer@ezana.047","172- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.047","Female",21945,"12-02-1995","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988097","Ezana-BMS-048","Lecturer 0048",355765,7023089556,"Lecturer@ezana.048","173- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.048","Female",21946,"12-02-1996","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988098","Ezana-BMS-049","Lecturer 0049",355766,7023089557,"Lecturer@ezana.049","174- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.049","Female",21947,"12-02-1997","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988099","Ezana-BMS-050","Lecturer 0050",355767,7023089558,"Lecturer@ezana.050","175- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.050","Female",21948,"12-02-1998","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988100","Ezana-BMS-051","Lecturer 0051",355768,7023089559,"Lecturer@ezana.051","176- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.051","Female",21949,"12-02-1999","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988101","Ezana-BMS-052","Lecturer 0052",355769,7023089560,"Lecturer@ezana.052","177- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.052","Female",21950,"12-02-2000","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988102","Ezana-BMS-053","Lecturer 0053",355770,7023089561,"Lecturer@ezana.053","178- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.053","Female",21951,"12-02-2001","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988103","Ezana-BMS-054","Lecturer 0054",355771,7023089562,"Lecturer@ezana.054","179- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.054","Male",21952,"12-02-2002","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988104","Ezana-BMS-055","Lecturer 0055",355772,7023089563,"Lecturer@ezana.055","180- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.055","Male",21953,"12-02-2003","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988105","Ezana-BMS-056","Lecturer 0056",355773,7023089564,"Lecturer@ezana.056","181- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.056","Male",21954,"12-02-2004","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988106","Ezana-BMS-057","Lecturer 0057",355774,7023089565,"Lecturer@ezana.057","182- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.057","Male",21955,"12-02-2005","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988107","Ezana-BMS-058","Lecturer 0058",355775,7023089566,"Lecturer@ezana.058","183- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.058","Male",21956,"12-02-2006","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988108","Ezana-BMS-059","Lecturer 0059",355776,7023089567,"Lecturer@ezana.059","184- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.059","Male",21957,"12-02-2007","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988109","Ezana-BMS-060","Lecturer 0060",355777,7023089568,"Lecturer@ezana.060","185- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.060","Male",21958,"12-02-2008","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988110","Ezana-BMS-061","Lecturer 0061",355778,7023089569,"Lecturer@ezana.061","186- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.061","Male",21959,"12-02-2009","On Work"),
("1258ce18b72f8a2f0e8b4f88813ca77d93988111","Ezana-BMS-062","Lecturer 0062",355779,7023089570,"Lecturer@ezana.062","187- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","ezana-BMS@ezana.062","Male",21960,"12-02-2010","On Work"),
("177c12314045714313d928b8a49d42638e3a13f418","BZAMN38092","James Doe",12790125,90125076342,"martdevelopers254@gmail.com","90126 Localhost","a69681bcf334ae130217fea4505fd3c994f5683f","devlan.jpg","30 Mar 2021","4613516b3bafbae4aceb88dc7b0f34bf30841c8cbc","School Of Business And Management Studies","BZAMN38092@ezana.org","Male",12709123,"12-02-1998","On Work"),
("ff8ce18b72f8a2f0e8b4f88813ca77d9398805fd8e","DPUSI40283","Mart Mbithi",127000,"+254790-089509","martdevelopers254@gmail.com","127- Localhost","4ffc966076ce2c03caf305019b9648a36ea79992","devlan.jpg","27 Mar 2021","53c904468e7edec9a7f2501d8a8c8d5140c434cb","School Of Computer Science","martmbithi@ezana.org","Male",21899,"12-02-2020","On Leave");


DROP TABLE IF EXISTS `ezanaLMS_ModuleAssignments`;

CREATE TABLE `ezanaLMS_ModuleAssignments` (
  `id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `submission_deadline` varchar(200) NOT NULL,
  `attachments` longtext NOT NULL,
  `faculty` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_ModuleAssignments` VALUES ("17fb8fb7c6906c6bb31113cef62c850ba02861e27a","BICM 102","Basic Calculus","2021-04-01 18:30:10","2021-04-27","Official Google Cloud Certified Associate Cloud Engineer Study Guide ( PDFDrive.com ).pdf","ba52fc866349d5af05addecba35600d0fd970ef7ba");


DROP TABLE IF EXISTS `ezanaLMS_ModuleAssigns`;

CREATE TABLE `ezanaLMS_ModuleAssigns` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lec_id` varchar(200) NOT NULL,
  `lec_name` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_ModuleMemo`;

CREATE TABLE `ezanaLMS_ModuleMemo` (
  `id` varchar(200) NOT NULL,
  `module_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_memo` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `faculty_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_ModuleRecommended`;

CREATE TABLE `ezanaLMS_ModuleRecommended` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `readingMaterials` varchar(200) NOT NULL,
  `external_link` varchar(200) NOT NULL,
  `visibility` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_ModuleRecommended` VALUES ("47c6321687a72a77507c5262ed711a510b80869a98","ba52fc866349d5af05addecba35600d0fd970ef7ba","BICM 102","Basic Calculus","Official Google Cloud Certified Associate Cloud Engineer Study Guide ( PDFDrive.com ).pdf","","Hidden","2021-04-01 18:29:40");


DROP TABLE IF EXISTS `ezanaLMS_Modules`;

CREATE TABLE `ezanaLMS_Modules` (
  `id` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `course_duration` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `exam_weight_percentage` varchar(200) NOT NULL,
  `cat_weight_percentage` varchar(200) NOT NULL,
  `lectures_number` varchar(200) NOT NULL,
  `details` longblob NOT NULL,
  `ass_status` tinyint(2) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Modules` VALUES ("052b62a629819a6e165078fab7071dec9f541f5321","BICM 103","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Numerical Computation","70 %","30 %",3,"Numerical analysis is the study of algorithms that use numerical approximation (as opposed to symbolic manipulations) for the problems of mathematical analysis (as distinguished from discrete mathematics). Numerical analysis naturally finds application in all fields of engineering and the physical sciences, but in the 21st century also the life sciences, social sciences, medicine, business and even the arts have adopted elements of scientific computations. The growth in computing power has revolutionized the use of realistic mathematical models in science and engineering, and subtle numerical analysis is required to implement these detailed models of the world. For example, ordinary differential equations appear in celestial mechanics (predicting the motions of planets, stars and galaxies); numerical linear algebra is important for data analysis;[2][3][4] stochastic differential equations and Markov chains are essential in simulating living cells for medicine and biology.\r\n\r\nBefore the advent of modern computers, numerical methods often depended on hand interpolation formulas applied to data from large printed tables. Since the mid 20th century, computers calculate the required functions instead, but many of the same formulas nevertheless continue to be used as part of the software algorithms.[5]\r\n\r\nThe numerical point of view goes back to the earliest mathematical writings. A tablet from the Yale Babylonian Collection (YBC 7289), gives a sexagesimal numerical approximation of the square root of 2, the length of the diagonal in a unit square.\r\n\r\nNumerical analysis continues this long tradition: rather than exact symbolic answers, which can only be applied to real-world measurements by translation into digits, it gives approximate solutions within specified error bounds. ",0,"29 Mar 2021",""),
("3699d9d9a098a82802aa8f2e674de7808d07cdcd52","BCS 1190","Bachelors In Computer Science","49943644fdc0a65810f0c2f58de2ec69d0c8a9d307","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Object Oriented Programming","70 %","30 %",2,"Object-oriented programming (OOP) is a programming paradigm based on the concept of \"objects\", which can contain data and code: data in the form of fields (often known as attributes or properties), and code, in the form of procedures (often known as methods).\r\n\r\nA feature of objects is that an object\'s own procedures can access and often modify the data fields of itself (objects have a notion of this or self). In OOP, computer programs are designed by making them out of objects that interact with one another.[1][2] OOP languages are diverse, but the most popular ones are class-based, meaning that objects are instances of classes, which also determine their types.\r\n\r\nMany of the most widely used programming languages (such as C++, Java, Python, etc.) are multi-paradigm and they support object-oriented programming to a greater or lesser degree, typically in combination with imperative, procedural programming. Significant object-oriented languages include: (list order based on TIOBE index) Java, C++, C#, Python, R, PHP, Visual Basic.NET, JavaScript, Ruby, Perl, Object Pascal, Objective-C, Dart, Swift, Scala, Kotlin, Common Lisp, MATLAB, and Smalltalk. ",0,"31 Mar 2021",""),
("b64d04da5331ebd753398d7c73ad69958048d5d9fe","BICM 102","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Basic Calculus","70 %","30 %",2,"Calculus, originally called infinitesimal calculus or \"the calculus of infinitesimals\", is the mathematical study of continuous change, in the same way that geometry is the study of shape and algebra is the study of generalizations of arithmetic operations.\r\n\r\nIt has two major branches, differential calculus and integral calculus; the former concerns instantaneous rates of change, and the slopes of curves, while integral calculus concerns accumulation of quantities, and areas under or between curves. These two branches are related to each other by the fundamental theorem of calculus, and they make use of the fundamental notions of convergence of infinite sequences and infinite series to a well-defined limit.[1]\r\n\r\nInfinitesimal calculus was developed independently in the late 17th century by Isaac Newton and Gottfried Wilhelm Leibniz.[2][3] Today, calculus has widespread uses in science, engineering, and economics.[4]\r\n\r\nIn mathematics education, calculus denotes courses of elementary mathematical analysis, which are mainly devoted to the study of functions and limits. The word calculus (plural calculi) is a Latin word, meaning originally \"small pebble\" (this meaning is kept in medicine – see Calculus (medicine)). Because such pebbles were used for counting (or measuring) a distance travelled by transportation devices in use in ancient Rome[5], the meaning of the word has evolved and today usually means a method of computation. It is therefore used for naming specific methods of calculation and related theories, such as propositional calculus, Ricci calculus, calculus of variations, lambda calculus, and process calculus. ",0,"29 Mar 2021",""),
("b9adc76da9eb039117c5e9b7bcbe302b0262f5744a","BICM 101","Bachelors In Computational Mathematics","78a65ef45e7ad2a9b201b96f227b353e3bd0ecf6b1","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Linear Algebra","70 %","30 %",2,"Linear algebra is the branch of mathematics concerning linear equations such as:\r\n\r\n    a 1 x 1 + ⋯ + a n x n = b , {\\displaystyle a_{1}x_{1}+\\cdots +a_{n}x_{n}=b,} {\\displaystyle a_{1}x_{1}+\\cdots +a_{n}x_{n}=b,}\r\n\r\nlinear maps such as:\r\n\r\n    ( x 1 , … , x n ) ↦ a 1 x 1 + ⋯ + a n x n , {\\displaystyle (x_{1},\\ldots ,x_{n})\\mapsto a_{1}x_{1}+\\cdots +a_{n}x_{n},} {\\displaystyle (x_{1},\\ldots ,x_{n})\\mapsto a_{1}x_{1}+\\cdots +a_{n}x_{n},}\r\n\r\nand their representations in vector spaces and through matrices.[1][2][3]\r\n\r\nLinear algebra is central to almost all areas of mathematics. For instance, linear algebra is fundamental in modern presentations of geometry, including for defining basic objects such as lines, planes and rotations. Also, functional analysis, a branch of mathematical analysis, may be viewed as basically the application of linear algebra to spaces of functions.\r\n\r\nLinear algebra is also used in most sciences and fields of engineering, because it allows modeling many natural phenomena, and computing efficiently with such models. For nonlinear systems, which cannot be modeled with linear algebra, it is often used for dealing with first-order approximations, using the fact that the differential of a multivariate function at a point is the linear map that best approximates the function near that point. ",0,"29 Mar 2021",""),
("eeb79907b162b0fc76bae42908cbc706cb7c9f750b","BSC 010","Bachelors In Computer Science","49943644fdc0a65810f0c2f58de2ec69d0c8a9d307","ba52fc866349d5af05addecba35600d0fd970ef7ba","4 Months","Programming Principles","70 %","30 %",3,"Offensive programming is a name used for the branch of defensive programming that expressly departs from defensive principles when dealing with errors resulting from software bugs. Although the name is a reaction to extreme interpretations of defensive programming, the two are not fundamentally in conflict. Rather, offensive programming adds an explicit priority of not tolerating errors in wrong places: the point where it departs from extreme interpretations of defensive programming is in preferring the presence of errors from within the program\'s line of defense to be blatantly obvious over the hypothetical safety benefit of tolerating them.[1][2] This preference is also what justifies using assertions.\r\n",0,"29 Mar 2021","");


DROP TABLE IF EXISTS `ezanaLMS_ModulesAnnouncements`;

CREATE TABLE `ezanaLMS_ModulesAnnouncements` (
  `id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `announcements` longblob NOT NULL,
  `attachments` longtext NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `faculty_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_PasswordResets`;

CREATE TABLE `ezanaLMS_PasswordResets` (
  `id` varchar(200) NOT NULL,
  `token` varchar(200) NOT NULL,
  `new_pass` varchar(200) NOT NULL,
  `acc_type` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_PastPapers`;

CREATE TABLE `ezanaLMS_PastPapers` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `paper_name` varchar(200) NOT NULL,
  `pastpaper` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `solution` varchar(200) NOT NULL,
  `solution_visibility` varchar(200) NOT NULL,
  `paper_visibility` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_PastPapers` VALUES ("5654abeb9d5cfeb52db75a5618d2d3bef3d5f3cd6b","ba52fc866349d5af05addecba35600d0fd970ef7ba","Basic Calculus","Bachelors In Computational Mathematics","Basic Calculus","StackOverflow Lite.pdf","2021-04-01 18:20:55","Politico Challenge.pdf","Available","Available");


DROP TABLE IF EXISTS `ezanaLMS_Settings`;

CREATE TABLE `ezanaLMS_Settings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `sysname` longtext NOT NULL,
  `logo` longtext NOT NULL,
  `version` varchar(200) NOT NULL,
  `policy` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Settings` VALUES (1,"Ezana","logo.png","1.3.0 Beta","");


DROP TABLE IF EXISTS `ezanaLMS_StudentAnswers`;

CREATE TABLE `ezanaLMS_StudentAnswers` (
  `id` varchar(200) NOT NULL,
  `exam_id` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `attachments` varchar(200) NOT NULL,
  `student_regno` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_StudentGrades`;

CREATE TABLE `ezanaLMS_StudentGrades` (
  `id` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `student_regno` varchar(200) NOT NULL,
  `marks_attained` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_StudentModuleGrades`;

CREATE TABLE `ezanaLMS_StudentModuleGrades` (
  `id` varchar(200) NOT NULL,
  `regno` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `marks` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_StudentModuleGrades` VALUES ("562145cfc18012c90197a76f5d9e9d856d7a3c193a","XBNYV13094","Student 003","BICM 102","Basic Calculus",89);


DROP TABLE IF EXISTS `ezanaLMS_Students`;

CREATE TABLE `ezanaLMS_Students` (
  `id` varchar(200) NOT NULL,
  `admno` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `adr` varchar(200) NOT NULL,
  `dob` varchar(200) NOT NULL,
  `idno` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `acc_status` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `day_enrolled` varchar(200) NOT NULL,
  `school` varchar(200) NOT NULL,
  `course` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `current_year` varchar(200) NOT NULL,
  `no_of_modules` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_Students` VALUES ("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865900","XBNYV13090","Student 001","martdevelopers254@gmail.com","a69681bcf334ae130217fea4505fd3c994f5683f",737229775,"127 Machakos","13 Jul 1998",1270003,"Male","Active","31 Mar 2021","31 Mar 2021","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865901","XBNYV13093","Student 002","student.ezana.002","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229776,"128 Machakos","14 Jul 1998",1270004,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865902","XBNYV13094","Student 003","student.ezana.003","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229777,"129 Machakos","15 Jul 1998",1270005,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865903","XBNYV13095","Student 004","student.ezana.004","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229778,"130 Machakos","16 Jul 1998",1270006,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865904","XBNYV13096","Student 005","student.ezana.005","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229779,"131 Machakos","17 Jul 1998",1270007,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865905","XBNYV13097","Student 006","student.ezana.006","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229780,"132 Machakos","18 Jul 1998",1270008,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865906","XBNYV13098","Student 007","student.ezana.007","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229781,"133 Machakos","19 Jul 1998",1270009,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865907","XBNYV13099","Student 008","student.ezana.008","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229782,"134 Machakos","20 Jul 1998",1270010,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865908","XBNYV13100","Student 009","student.ezana.009","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229783,"135 Machakos","21 Jul 1998",1270011,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865909","XBNYV13101","Student 010","student.ezana.010","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229784,"136 Machakos","22 Jul 1998",1270012,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865910","XBNYV13102","Student 011","student.ezana.011","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229785,"137 Machakos","23 Jul 1998",1270013,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865911","XBNYV13103","Student 012","student.ezana.012","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229786,"138 Machakos","24 Jul 1998",1270014,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865912","XBNYV13104","Student 013","student.ezana.013","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229787,"139 Machakos","25 Jul 1998",1270015,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865913","XBNYV13105","Student 014","student.ezana.014","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229788,"140 Machakos","26 Jul 1998",1270016,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865914","XBNYV13106","Student 015","student.ezana.015","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229789,"141 Machakos","27 Jul 1998",1270017,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865915","XBNYV13107","Student 016","student.ezana.016","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229790,"142 Machakos","28 Jul 1998",1270018,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865916","XBNYV13108","Student 017","student.ezana.017","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229791,"143 Machakos","13 Jul 1998",1270019,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865917","XBNYV13109","Student 018","student.ezana.018","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229792,"144 Machakos","14 Jul 1998",1270020,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865918","XBNYV13110","Student 019","student.ezana.019","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229793,"145 Machakos","15 Jul 1998",1270021,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865919","XBNYV13111","Student 020","student.ezana.020","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229794,"146 Machakos","16 Jul 1998",1270022,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865920","XBNYV13112","Student 021","student.ezana.021","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229795,"147 Machakos","17 Jul 1998",1270023,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865921","XBNYV13113","Student 022","student.ezana.022","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229796,"148 Machakos","18 Jul 1998",1270024,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865922","XBNYV13114","Student 023","student.ezana.023","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229797,"149 Machakos","19 Jul 1998",1270025,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865923","XBNYV13115","Student 024","student.ezana.024","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229798,"150 Machakos","20 Jul 1998",1270026,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865924","XBNYV13116","Student 025","student.ezana.025","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229799,"151 Machakos","21 Jul 1998",1270027,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865925","XBNYV13117","Student 026","student.ezana.026","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229800,"152 Machakos","22 Jul 1998",1270028,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865926","XBNYV13118","Student 027","student.ezana.027","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229801,"153 Machakos","23 Jul 1998",1270029,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865927","XBNYV13119","Student 028","student.ezana.028","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229802,"154 Machakos","24 Jul 1998",1270030,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865928","XBNYV13120","Student 029","student.ezana.029","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229803,"155 Machakos","25 Jul 1998",1270031,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865929","XBNYV13121","Student 030","student.ezana.030","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229804,"156 Machakos","26 Jul 1998",1270032,"Male","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865930","XBNYV13122","Student 031","student@ezana.031","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229805,"157 Machakos","27 Jul 1998",1270033,"Male","Active","31 Mar 2021","31 Mar 2021","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",4),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865931","XBNYV13123","Student 032","student.ezana.032","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229806,"158 Machakos","28 Jul 1998",1270034,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865932","XBNYV13124","Student 033","student.ezana.033","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229807,"159 Machakos","13 Jul 1998",1270035,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865933","XBNYV13125","Student 034","student.ezana.034","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229808,"160 Machakos","14 Jul 1998",1270036,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865934","XBNYV13126","Student 035","student.ezana.035","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229809,"161 Machakos","15 Jul 1998",1270037,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865935","XBNYV13127","Student 036","student.ezana.036","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229810,"162 Machakos","16 Jul 1998",1270038,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865936","XBNYV13128","Student 037","student.ezana.037","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229811,"163 Machakos","17 Jul 1998",1270039,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865937","XBNYV13129","Student 038","student.ezana.038","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229812,"164 Machakos","18 Jul 1998",1270040,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5),
("6d39379f9ccb763e9b4b8cb4bdf5753e5ca0865938","XBNYV13130","Student 039","student.ezana.039","6bac0eccd8e0600ca0fa68712ff9a6e45588cefd",737229813,"165 Machakos","19 Jul 1998",1270041,"Female","Active","31 Mar 2021","","","ba52fc866349d5af05addecba35600d0fd970ef7ba","13 Jul 2020","School Of Computing Sciences","Bachelors In Computer Science","Computer Science","1st Year",5);


DROP TABLE IF EXISTS `ezanaLMS_StudentsGroups`;

CREATE TABLE `ezanaLMS_StudentsGroups` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `student_admn` varchar(200) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_StudentsGroups` VALUES ("939bbdffe61ac37fedc1d2dd1d73dbd36369b0f41a","ba52fc866349d5af05addecba35600d0fd970ef7ba","Group 001","JMKHF96831","XBNYV13093","Student 002","2021-04-01 18:28:13"),
("aa99129ea9b559c11be91dc7a6556607246224f2e3","ba52fc866349d5af05addecba35600d0fd970ef7ba","Group 001","JMKHF96831","XBNYV13096","Student 005","2021-04-01 18:28:20"),
("cd6eb874c41507d6164ecdb0a8837df3e8c79fcaa5","ba52fc866349d5af05addecba35600d0fd970ef7ba","Group 001","JMKHF96831","XBNYV13094","Student 003","2021-04-01 18:28:02");


DROP TABLE IF EXISTS `ezanaLMS_TimeTable`;

CREATE TABLE `ezanaLMS_TimeTable` (
  `id` varchar(200) NOT NULL,
  `faculty_id` varchar(200) NOT NULL,
  `course_code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `module_code` varchar(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lecturer` varchar(200) NOT NULL,
  `day` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `room` varchar(200) NOT NULL,
  `link` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `ezanaLMS_UserLog`;

CREATE TABLE `ezanaLMS_UserLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(200) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `ezanaLMS_UserLog` VALUES (1,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-03-30 17:32:02"),
(2,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-03-30 18:16:21"),
(3,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-03-31 09:45:08"),
(4,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-03-31 12:06:04"),
(5,"a69681bcf334ae130217fea4505fd3c994f5683f","sysadmin@ezana.org","127.0.0.1","2021-04-01 18:13:04");


DROP TABLE IF EXISTS `likes`;

CREATE TABLE `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `like` int(1) NOT NULL DEFAULT '0' COMMENT '1 = Like\n0 = Does not metter\n-1 = Dislike',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `videos_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_likes_videos1_idx` (`videos_id`),
  KEY `fk_likes_users1_idx` (`users_id`),
  KEY `likes_likes_idx` (`like`),
  CONSTRAINT `fk_likes_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_likes_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `playlists`;

CREATE TABLE `playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `status` enum('public','private','unlisted','favorite','watch_later') NOT NULL DEFAULT 'public',
  `showOnTV` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_playlists_users1_idx` (`users_id`),
  KEY `showOnTVindex3` (`showOnTV`),
  CONSTRAINT `fk_playlists_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `playlists_has_videos`;

CREATE TABLE `playlists_has_videos` (
  `playlists_id` int(11) NOT NULL,
  `videos_id` int(11) NOT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`playlists_id`,`videos_id`),
  KEY `fk_playlists_has_videos_videos1_idx` (`videos_id`),
  KEY `fk_playlists_has_videos_playlists1_idx` (`playlists_id`),
  CONSTRAINT `fk_playlists_has_videos_playlists1` FOREIGN KEY (`playlists_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_playlists_has_videos_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `plugins`;

CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(45) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `object_data` text,
  `name` varchar(255) NOT NULL,
  `dirName` varchar(255) NOT NULL,
  `pluginversion` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid_UNIQUE` (`uuid`),
  KEY `plugin_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `plugins` VALUES (1,"a06505bf-3570-4b1f-977a-fd0e5cab205d","active","2021-03-26 21:38:38","2021-03-26 21:38:38","","Gallery","Gallery","1.0"),
(2,"layout84-8f5a-4d1b-b912-172c608bf9e3","active","2021-03-26 21:38:38","2021-03-26 21:38:38","{\"showButtonNotification\":false,\"pageLoader\":{\"type\":{\"0\":\"-- Random\",\"circle\":\"Circle\",\"roller\":\"Roller\",\"facebook\":\"Facebook\",\"spinner\":\"Spinner\",\"heart\":\"Heart\",\"ripple\":\"Ripple\",\"avideo\":\"Avideo\",\"grid\":\"Grid\",\"default\":\"Default\",\"matrix\":\"Matrix\",\"ellipsis\":\"Ellipsis\",\"ring\":\"Ring\",\"hourglass\":\"Hourglass\",\"jumpingDots\":\"JumpingDots\",\"dual-ring\":\"Dual-ring\",\"loaderXLVI\":\"LoaderXLVI\"},\"value\":\"avideo\"}}","Layout","Layout","1.1"),
(3,"55a4fa56-8a30-48d4-a0fb-8aa6b3fuser3","active","2021-03-26 21:38:38","2021-03-26 21:38:38","{\"nonAdminCannotDownload\":false,\"userCanAllowFilesDownload\":false,\"userCanAllowFilesShare\":false,\"userCanAllowFilesDownloadSelectPerVideo\":false,\"userCanAllowFilesShareSelectPerVideo\":false,\"blockEmbedFromSharedVideos\":true,\"userCanProtectVideosWithPassword\":true,\"userCanChangeVideoOwner\":false,\"usersCanCreateNewCategories\":false,\"userCanNotChangeCategory\":false,\"userCanNotChangeUserGroup\":false,\"userDefaultUserGroup\":{\"type\":[\"Default\"],\"value\":0},\"userMustBeLoggedIn\":false,\"userMustBeLoggedInCloseButtonURL\":\"\",\"onlyVerifiedEmailCanUpload\":false,\"sendVerificationMailAutomaic\":false,\"verificationMailTextLine1\":\"Just a quick note to say a big welcome and an even bigger thank you for registering\",\"verificationMailTextLine2\":\"Cheers, %s Team.\",\"verificationMailTextLine3\":\"You are just one click away from starting your journey with %s!\",\"verificationMailTextLine4\":\"All you need to do is to verify your e-mail by clicking the link below\",\"unverifiedEmailsCanNOTLogin\":false,\"unverifiedEmailsCanNOTComment\":false,\"newUsersCanStream\":false,\"doNotIndentifyByEmail\":false,\"doNotIndentifyByName\":false,\"doNotIndentifyByUserName\":false,\"hideRemoveChannelFromModeYoutube\":false,\"showChannelBannerOnModeYoutube\":false,\"showChannelHomeTab\":true,\"showChannelVideosTab\":true,\"showChannelProgramsTab\":true,\"showBigVideoOnChannelVideosTab\":true,\"encryptPasswordsWithSalt\":false,\"requestCaptchaAfterLoginsAttempts\":0,\"disableSignOutButton\":false,\"disableNativeSignUp\":false,\"disableNativeSignIn\":false,\"disablePersonalInfo\":true,\"loginBackgroundAnimation\":{\"type\":{\"0\":\"-- None\",\"1\":\"-- Random\",\"Breeze\":\"Breeze\",\"Animated\":\"Animated\",\"Bokeh\":\"Bokeh\",\"Animated3\":\"Animated3\",\"Animated4\":\"Animated4\"},\"value\":1},\"userCanChangeUsername\":true,\"signInOnRight\":false,\"doNotShowRightProfile\":false,\"doNotShowLeftProfile\":false,\"forceLoginToBeTheEmail\":false,\"emailMustBeUnique\":false,\"messageToAppearBelowLoginBox\":{\"type\":\"textarea\",\"value\":\"\"},\"messageToAppearAboveSignUpBox\":{\"type\":\"textarea\",\"value\":\"\"},\"keepViewerOnChannel\":false,\"showLeaveChannelButton\":false,\"addChannelNameOnLinks\":true,\"doNotShowTopBannerOnChannel\":false,\"doNotShowMyChannelNameOnBasicInfo\":false,\"doNotShowMyAnalyticsCodeOnBasicInfo\":false,\"doNotShowMyAboutOnBasicInfo\":false,\"MyChannelLabel\":\"My Channel\",\"afterLoginGoToMyChannel\":false,\"afterLoginGoToURL\":\"\",\"afterLogoffGoToMyChannel\":false,\"afterLogoffGoToURL\":\"\",\"allowDonationLink\":false,\"donationButtonLabel\":\"Donation\",\"allowWalletDirectTransferDonation\":false,\"donationWalletButtonLabel\":\"Donatate from your wallet\",\"showEmailVerifiedMark\":true,\"Checkmark1Enabled\":true,\"Checkmark1HTML\":\"<i class=\\\"fas fa-check\\\" data-toggle=\\\"tooltip\\\" data-placement=\\\"bottom\\\" title=\\\"Trustable User\\\"><\\/i>\",\"Checkmark2Enabled\":true,\"Checkmark2HTML\":\"<i class=\\\"fas fa-shield-alt\\\" data-toggle=\\\"tooltip\\\" data-placement=\\\"bottom\\\" title=\\\"Official User\\\"><\\/i>\",\"Checkmark3Enabled\":true,\"Checkmark3HTML\":\"<i class=\\\"fas fa-certificate fa-spin\\\" data-toggle=\\\"tooltip\\\" data-placement=\\\"bottom\\\" title=\\\"Premium User\\\"><\\/i>\",\"autoSaveUsersOnCategorySelectedGroups\":false,\"enableExtraInfo\":false}","CustomizeUser","CustomizeUser","3.0"),
(4,"55a4fa56-8a30-48d4-a0fb-8aa6b3f69033","active","2021-03-26 21:38:38","2021-03-26 21:38:38","{\"logoMenuBarURL\":\"\",\"encoderNetwork\":\"https:\\/\\/network.avideo.com\\/\",\"useEncoderNetworkRecomendation\":false,\"doNotShowEncoderNetwork\":true,\"doNotShowUploadButton\":false,\"uploadButtonDropdownIcon\":\"fas fa-video\",\"uploadButtonDropdownText\":\"\",\"encoderNetworkLabel\":\"\",\"doNotShowUploadMP4Button\":true,\"disablePDFUpload\":false,\"disableImageUpload\":false,\"disableZipUpload\":true,\"disableMP4Upload\":false,\"disableMP3Upload\":false,\"uploadMP4ButtonLabel\":\"\",\"doNotShowImportMP4Button\":true,\"importMP4ButtonLabel\":\"\",\"doNotShowEncoderButton\":false,\"encoderButtonLabel\":\"\",\"doNotShowEmbedButton\":false,\"embedBackgroundColor\":\"white\",\"embedButtonLabel\":\"\",\"embedCodeTemplate\":\"<div class=\\\"embed-responsive embed-responsive-16by9\\\"><iframe width=\\\"640\\\" height=\\\"360\\\" style=\\\"max-width: 100%;max-height: 100%; border:none;\\\" src=\\\"{embedURL}\\\" frameborder=\\\"0\\\" allowfullscreen=\\\"allowfullscreen\\\" allow=\\\"autoplay\\\" scrolling=\\\"no\\\">iFrame is not supported!<\\/iframe><\\/div>\",\"embedCodeTemplateObject\":\"<div class=\\\"embed-responsive embed-responsive-16by9\\\"><object width=\\\"640\\\" height=\\\"360\\\"><param name=\\\"movie\\\" value=\\\"{embedURL}\\\"><\\/param><param name=\\\"allowFullScreen\\\" value=\\\"true\\\"><\\/param><param name=\\\"allowscriptaccess\\\" value=\\\"always\\\"><\\/param><embed src=\\\"{embedURL}\\\" allowscriptaccess=\\\"always\\\" allowfullscreen=\\\"true\\\" width=\\\"640\\\" height=\\\"360\\\"><\\/embed><\\/object><\\/div>\",\"htmlCodeTemplate\":\"<a href=\\\"{permaLink}\\\"><img src=\\\"{imgSRC}\\\">{title}<\\/a>\",\"BBCodeTemplate\":\"[url={permaLink}][img]{imgSRC}[\\/img]{title}[\\/url]\",\"doNotShowEncoderHLS\":false,\"doNotShowEncoderResolutionLow\":false,\"doNotShowEncoderResolutionSD\":false,\"doNotShowEncoderResolutionHD\":false,\"openEncoderInIFrame\":false,\"showOnlyEncoderAutomaticResolutions\":true,\"doNotShowEncoderAutomaticHLS\":false,\"doNotShowEncoderAutomaticMP4\":false,\"doNotShowEncoderAutomaticWebm\":false,\"doNotShowEncoderAutomaticAudio\":false,\"doNotShowExtractAudio\":false,\"doNotShowCreateVideoSpectrum\":false,\"doNotShowLeftMenuAudioAndVideoButtons\":false,\"doNotShowWebsiteOnContactForm\":false,\"doNotUseXsendFile\":false,\"makeVideosInactiveAfterEncode\":false,\"makeVideosUnlistedAfterEncode\":false,\"usePermalinks\":false,\"useVideoIDOnSEOLinks\":true,\"disableAnimatedGif\":false,\"removeBrowserChannelLinkFromMenu\":false,\"EnableMinifyJS\":false,\"disableShareAndPlaylist\":false,\"disableShareOnly\":false,\"disableEmailSharing\":false,\"splitBulkEmailSend\":50,\"disableComments\":false,\"commentsMaxLength\":200,\"commentsNoIndex\":false,\"disableYoutubePlayerIntegration\":false,\"utf8Encode\":false,\"utf8Decode\":false,\"menuBarHTMLCode\":{\"type\":\"textarea\",\"value\":\"\"},\"underMenuBarHTMLCode\":{\"type\":\"textarea\",\"value\":\"\"},\"footerHTMLCode\":{\"type\":\"textarea\",\"value\":\"\"},\"signInOnRight\":true,\"signInOnLeft\":true,\"forceCategory\":false,\"showCategoryTopImages\":true,\"autoPlayAjax\":false,\"disablePlayLink\":false,\"disableHelpLeftMenu\":false,\"disableAboutLeftMenu\":false,\"disableContactLeftMenu\":false,\"disableNavbar\":false,\"disableNavBarInsideIframe\":true,\"autoHideNavbar\":true,\"autoHideNavbarInSeconds\":0,\"videosCDN\":\"\",\"useFFMPEGToGenerateThumbs\":false,\"thumbsWidthPortrait\":170,\"thumbsHeightPortrait\":250,\"thumbsWidthLandscape\":640,\"thumbsHeightLandscape\":360,\"showImageDownloadOption\":false,\"doNotDisplayViews\":false,\"doNotDisplayLikes\":false,\"doNotDisplayCategoryLeftMenu\":false,\"doNotDisplayCategory\":false,\"doNotDisplayGroupsTags\":false,\"doNotDisplayPluginsTags\":false,\"showNotRatedLabel\":false,\"showShareMenuOpenByDefault\":false,\"askRRatingConfirmationBeforePlay_G\":false,\"askRRatingConfirmationBeforePlay_PG\":false,\"askRRatingConfirmationBeforePlay_PG13\":false,\"askRRatingConfirmationBeforePlay_R\":false,\"askRRatingConfirmationBeforePlay_NC17\":true,\"askRRatingConfirmationBeforePlay_MA\":true,\"filterRRating\":false,\"AsyncJobs\":false,\"doNotShowLeftHomeButton\":false,\"doNotShowLeftTrendingButton\":false,\"CategoryLabel\":\"Categories\",\"ShowAllVideosOnCategory\":false,\"hideCategoryVideosCount\":false,\"paidOnlyUsersTellWhatVideoIs\":false,\"paidOnlyShowLabels\":false,\"paidOnlyLabel\":\"Premium\",\"paidOnlyFreeLabel\":\"Free\",\"removeSubscribeButton\":false,\"removeThumbsUpAndDown\":false,\"videoNotFoundText\":{\"type\":\"textarea\",\"value\":\"\"},\"siteMapRowsLimit\":100,\"siteMapUTF8Fix\":false,\"showPrivateVideosOnSitemap\":false,\"enableOldPassHashCheck\":true,\"disableHTMLDescription\":false,\"disableVideoSwap\":false,\"makeSwapVideosOnlyForAdmin\":false,\"disableCopyEmbed\":false,\"disableDownloadVideosList\":false,\"videosManegerRowCount\":\"[10, 25, 50, -1]\",\"videosListRowCount\":\"[10, 20, 30, 40, 50]\",\"twitter_site\":\"@127001\",\"twitter_player\":true,\"twitter_summary_large_image\":false,\"footerStyle\":\"position: fixed;bottom: 0;width: 100%;\",\"disableVideoTags\":false,\"doNotAllowEncoderOverwriteStatus\":false,\"timeZone\":{\"type\":[\"Africa\\/Abidjan\",\"Africa\\/Accra\",\"Africa\\/Addis_Ababa\",\"Africa\\/Algiers\",\"Africa\\/Asmara\",\"Africa\\/Bamako\",\"Africa\\/Bangui\",\"Africa\\/Banjul\",\"Africa\\/Bissau\",\"Africa\\/Blantyre\",\"Africa\\/Brazzaville\",\"Africa\\/Bujumbura\",\"Africa\\/Cairo\",\"Africa\\/Casablanca\",\"Africa\\/Ceuta\",\"Africa\\/Conakry\",\"Africa\\/Dakar\",\"Africa\\/Dar_es_Salaam\",\"Africa\\/Djibouti\",\"Africa\\/Douala\",\"Africa\\/El_Aaiun\",\"Africa\\/Freetown\",\"Africa\\/Gaborone\",\"Africa\\/Harare\",\"Africa\\/Johannesburg\",\"Africa\\/Juba\",\"Africa\\/Kampala\",\"Africa\\/Khartoum\",\"Africa\\/Kigali\",\"Africa\\/Kinshasa\",\"Africa\\/Lagos\",\"Africa\\/Libreville\",\"Africa\\/Lome\",\"Africa\\/Luanda\",\"Africa\\/Lubumbashi\",\"Africa\\/Lusaka\",\"Africa\\/Malabo\",\"Africa\\/Maputo\",\"Africa\\/Maseru\",\"Africa\\/Mbabane\",\"Africa\\/Mogadishu\",\"Africa\\/Monrovia\",\"Africa\\/Nairobi\",\"Africa\\/Ndjamena\",\"Africa\\/Niamey\",\"Africa\\/Nouakchott\",\"Africa\\/Ouagadougou\",\"Africa\\/Porto-Novo\",\"Africa\\/Sao_Tome\",\"Africa\\/Tripoli\",\"Africa\\/Tunis\",\"Africa\\/Windhoek\",\"America\\/Adak\",\"America\\/Anchorage\",\"America\\/Anguilla\",\"America\\/Antigua\",\"America\\/Araguaina\",\"America\\/Argentina\\/Buenos_Aires\",\"America\\/Argentina\\/Catamarca\",\"America\\/Argentina\\/Cordoba\",\"America\\/Argentina\\/Jujuy\",\"America\\/Argentina\\/La_Rioja\",\"America\\/Argentina\\/Mendoza\",\"America\\/Argentina\\/Rio_Gallegos\",\"America\\/Argentina\\/Salta\",\"America\\/Argentina\\/San_Juan\",\"America\\/Argentina\\/San_Luis\",\"America\\/Argentina\\/Tucuman\",\"America\\/Argentina\\/Ushuaia\",\"America\\/Aruba\",\"America\\/Asuncion\",\"America\\/Atikokan\",\"America\\/Bahia\",\"America\\/Bahia_Banderas\",\"America\\/Barbados\",\"America\\/Belem\",\"America\\/Belize\",\"America\\/Blanc-Sablon\",\"America\\/Boa_Vista\",\"America\\/Bogota\",\"America\\/Boise\",\"America\\/Cambridge_Bay\",\"America\\/Campo_Grande\",\"America\\/Cancun\",\"America\\/Caracas\",\"America\\/Cayenne\",\"America\\/Cayman\",\"America\\/Chicago\",\"America\\/Chihuahua\",\"America\\/Costa_Rica\",\"America\\/Creston\",\"America\\/Cuiaba\",\"America\\/Curacao\",\"America\\/Danmarkshavn\",\"America\\/Dawson\",\"America\\/Dawson_Creek\",\"America\\/Denver\",\"America\\/Detroit\",\"America\\/Dominica\",\"America\\/Edmonton\",\"America\\/Eirunepe\",\"America\\/El_Salvador\",\"America\\/Fort_Nelson\",\"America\\/Fortaleza\",\"America\\/Glace_Bay\",\"America\\/Godthab\",\"America\\/Goose_Bay\",\"America\\/Grand_Turk\",\"America\\/Grenada\",\"America\\/Guadeloupe\",\"America\\/Guatemala\",\"America\\/Guayaquil\",\"America\\/Guyana\",\"America\\/Halifax\",\"America\\/Havana\",\"America\\/Hermosillo\",\"America\\/Indiana\\/Indianapolis\",\"America\\/Indiana\\/Knox\",\"America\\/Indiana\\/Marengo\",\"America\\/Indiana\\/Petersburg\",\"America\\/Indiana\\/Tell_City\",\"America\\/Indiana\\/Vevay\",\"America\\/Indiana\\/Vincennes\",\"America\\/Indiana\\/Winamac\",\"America\\/Inuvik\",\"America\\/Iqaluit\",\"America\\/Jamaica\",\"America\\/Juneau\",\"America\\/Kentucky\\/Louisville\",\"America\\/Kentucky\\/Monticello\",\"America\\/Kralendijk\",\"America\\/La_Paz\",\"America\\/Lima\",\"America\\/Los_Angeles\",\"America\\/Lower_Princes\",\"America\\/Maceio\",\"America\\/Managua\",\"America\\/Manaus\",\"America\\/Marigot\",\"America\\/Martinique\",\"America\\/Matamoros\",\"America\\/Mazatlan\",\"America\\/Menominee\",\"America\\/Merida\",\"America\\/Metlakatla\",\"America\\/Mexico_City\",\"America\\/Miquelon\",\"America\\/Moncton\",\"America\\/Monterrey\",\"America\\/Montevideo\",\"America\\/Montserrat\",\"America\\/Nassau\",\"America\\/New_York\",\"America\\/Nipigon\",\"America\\/Nome\",\"America\\/Noronha\",\"America\\/North_Dakota\\/Beulah\",\"America\\/North_Dakota\\/Center\",\"America\\/North_Dakota\\/New_Salem\",\"America\\/Ojinaga\",\"America\\/Panama\",\"America\\/Pangnirtung\",\"America\\/Paramaribo\",\"America\\/Phoenix\",\"America\\/Port-au-Prince\",\"America\\/Port_of_Spain\",\"America\\/Porto_Velho\",\"America\\/Puerto_Rico\",\"America\\/Punta_Arenas\",\"America\\/Rainy_River\",\"America\\/Rankin_Inlet\",\"America\\/Recife\",\"America\\/Regina\",\"America\\/Resolute\",\"America\\/Rio_Branco\",\"America\\/Santarem\",\"America\\/Santiago\",\"America\\/Santo_Domingo\",\"America\\/Sao_Paulo\",\"America\\/Scoresbysund\",\"America\\/Sitka\",\"America\\/St_Barthelemy\",\"America\\/St_Johns\",\"America\\/St_Kitts\",\"America\\/St_Lucia\",\"America\\/St_Thomas\",\"America\\/St_Vincent\",\"America\\/Swift_Current\",\"America\\/Tegucigalpa\",\"America\\/Thule\",\"America\\/Thunder_Bay\",\"America\\/Tijuana\",\"America\\/Toronto\",\"America\\/Tortola\",\"America\\/Vancouver\",\"America\\/Whitehorse\",\"America\\/Winnipeg\",\"America\\/Yakutat\",\"America\\/Yellowknife\",\"Antarctica\\/Casey\",\"Antarctica\\/Davis\",\"Antarctica\\/DumontDUrville\",\"Antarctica\\/Macquarie\",\"Antarctica\\/Mawson\",\"Antarctica\\/McMurdo\",\"Antarctica\\/Palmer\",\"Antarctica\\/Rothera\",\"Antarctica\\/Syowa\",\"Antarctica\\/Troll\",\"Antarctica\\/Vostok\",\"Arctic\\/Longyearbyen\",\"Asia\\/Aden\",\"Asia\\/Almaty\",\"Asia\\/Amman\",\"Asia\\/Anadyr\",\"Asia\\/Aqtau\",\"Asia\\/Aqtobe\",\"Asia\\/Ashgabat\",\"Asia\\/Atyrau\",\"Asia\\/Baghdad\",\"Asia\\/Bahrain\",\"Asia\\/Baku\",\"Asia\\/Bangkok\",\"Asia\\/Barnaul\",\"Asia\\/Beirut\",\"Asia\\/Bishkek\",\"Asia\\/Brunei\",\"Asia\\/Chita\",\"Asia\\/Choibalsan\",\"Asia\\/Colombo\",\"Asia\\/Damascus\",\"Asia\\/Dhaka\",\"Asia\\/Dili\",\"Asia\\/Dubai\",\"Asia\\/Dushanbe\",\"Asia\\/Famagusta\",\"Asia\\/Gaza\",\"Asia\\/Hebron\",\"Asia\\/Ho_Chi_Minh\",\"Asia\\/Hong_Kong\",\"Asia\\/Hovd\",\"Asia\\/Irkutsk\",\"Asia\\/Jakarta\",\"Asia\\/Jayapura\",\"Asia\\/Jerusalem\",\"Asia\\/Kabul\",\"Asia\\/Kamchatka\",\"Asia\\/Karachi\",\"Asia\\/Kathmandu\",\"Asia\\/Khandyga\",\"Asia\\/Kolkata\",\"Asia\\/Krasnoyarsk\",\"Asia\\/Kuala_Lumpur\",\"Asia\\/Kuching\",\"Asia\\/Kuwait\",\"Asia\\/Macau\",\"Asia\\/Magadan\",\"Asia\\/Makassar\",\"Asia\\/Manila\",\"Asia\\/Muscat\",\"Asia\\/Nicosia\",\"Asia\\/Novokuznetsk\",\"Asia\\/Novosibirsk\",\"Asia\\/Omsk\",\"Asia\\/Oral\",\"Asia\\/Phnom_Penh\",\"Asia\\/Pontianak\",\"Asia\\/Pyongyang\",\"Asia\\/Qatar\",\"Asia\\/Qyzylorda\",\"Asia\\/Riyadh\",\"Asia\\/Sakhalin\",\"Asia\\/Samarkand\",\"Asia\\/Seoul\",\"Asia\\/Shanghai\",\"Asia\\/Singapore\",\"Asia\\/Srednekolymsk\",\"Asia\\/Taipei\",\"Asia\\/Tashkent\",\"Asia\\/Tbilisi\",\"Asia\\/Tehran\",\"Asia\\/Thimphu\",\"Asia\\/Tokyo\",\"Asia\\/Tomsk\",\"Asia\\/Ulaanbaatar\",\"Asia\\/Urumqi\",\"Asia\\/Ust-Nera\",\"Asia\\/Vientiane\",\"Asia\\/Vladivostok\",\"Asia\\/Yakutsk\",\"Asia\\/Yangon\",\"Asia\\/Yekaterinburg\",\"Asia\\/Yerevan\",\"Atlantic\\/Azores\",\"Atlantic\\/Bermuda\",\"Atlantic\\/Canary\",\"Atlantic\\/Cape_Verde\",\"Atlantic\\/Faroe\",\"Atlantic\\/Madeira\",\"Atlantic\\/Reykjavik\",\"Atlantic\\/South_Georgia\",\"Atlantic\\/St_Helena\",\"Atlantic\\/Stanley\",\"Australia\\/Adelaide\",\"Australia\\/Brisbane\",\"Australia\\/Broken_Hill\",\"Australia\\/Currie\",\"Australia\\/Darwin\",\"Australia\\/Eucla\",\"Australia\\/Hobart\",\"Australia\\/Lindeman\",\"Australia\\/Lord_Howe\",\"Australia\\/Melbourne\",\"Australia\\/Perth\",\"Australia\\/Sydney\",\"Europe\\/Amsterdam\",\"Europe\\/Andorra\",\"Europe\\/Astrakhan\",\"Europe\\/Athens\",\"Europe\\/Belgrade\",\"Europe\\/Berlin\",\"Europe\\/Bratislava\",\"Europe\\/Brussels\",\"Europe\\/Bucharest\",\"Europe\\/Budapest\",\"Europe\\/Busingen\",\"Europe\\/Chisinau\",\"Europe\\/Copenhagen\",\"Europe\\/Dublin\",\"Europe\\/Gibraltar\",\"Europe\\/Guernsey\",\"Europe\\/Helsinki\",\"Europe\\/Isle_of_Man\",\"Europe\\/Istanbul\",\"Europe\\/Jersey\",\"Europe\\/Kaliningrad\",\"Europe\\/Kiev\",\"Europe\\/Kirov\",\"Europe\\/Lisbon\",\"Europe\\/Ljubljana\",\"Europe\\/London\",\"Europe\\/Luxembourg\",\"Europe\\/Madrid\",\"Europe\\/Malta\",\"Europe\\/Mariehamn\",\"Europe\\/Minsk\",\"Europe\\/Monaco\",\"Europe\\/Moscow\",\"Europe\\/Oslo\",\"Europe\\/Paris\",\"Europe\\/Podgorica\",\"Europe\\/Prague\",\"Europe\\/Riga\",\"Europe\\/Rome\",\"Europe\\/Samara\",\"Europe\\/San_Marino\",\"Europe\\/Sarajevo\",\"Europe\\/Saratov\",\"Europe\\/Simferopol\",\"Europe\\/Skopje\",\"Europe\\/Sofia\",\"Europe\\/Stockholm\",\"Europe\\/Tallinn\",\"Europe\\/Tirane\",\"Europe\\/Ulyanovsk\",\"Europe\\/Uzhgorod\",\"Europe\\/Vaduz\",\"Europe\\/Vatican\",\"Europe\\/Vienna\",\"Europe\\/Vilnius\",\"Europe\\/Volgograd\",\"Europe\\/Warsaw\",\"Europe\\/Zagreb\",\"Europe\\/Zaporozhye\",\"Europe\\/Zurich\",\"Indian\\/Antananarivo\",\"Indian\\/Chagos\",\"Indian\\/Christmas\",\"Indian\\/Cocos\",\"Indian\\/Comoro\",\"Indian\\/Kerguelen\",\"Indian\\/Mahe\",\"Indian\\/Maldives\",\"Indian\\/Mauritius\",\"Indian\\/Mayotte\",\"Indian\\/Reunion\",\"Pacific\\/Apia\",\"Pacific\\/Auckland\",\"Pacific\\/Bougainville\",\"Pacific\\/Chatham\",\"Pacific\\/Chuuk\",\"Pacific\\/Easter\",\"Pacific\\/Efate\",\"Pacific\\/Enderbury\",\"Pacific\\/Fakaofo\",\"Pacific\\/Fiji\",\"Pacific\\/Funafuti\",\"Pacific\\/Galapagos\",\"Pacific\\/Gambier\",\"Pacific\\/Guadalcanal\",\"Pacific\\/Guam\",\"Pacific\\/Honolulu\",\"Pacific\\/Kiritimati\",\"Pacific\\/Kosrae\",\"Pacific\\/Kwajalein\",\"Pacific\\/Majuro\",\"Pacific\\/Marquesas\",\"Pacific\\/Midway\",\"Pacific\\/Nauru\",\"Pacific\\/Niue\",\"Pacific\\/Norfolk\",\"Pacific\\/Noumea\",\"Pacific\\/Pago_Pago\",\"Pacific\\/Palau\",\"Pacific\\/Pitcairn\",\"Pacific\\/Pohnpei\",\"Pacific\\/Port_Moresby\",\"Pacific\\/Rarotonga\",\"Pacific\\/Saipan\",\"Pacific\\/Tahiti\",\"Pacific\\/Tarawa\",\"Pacific\\/Tongatapu\",\"Pacific\\/Wake\",\"Pacific\\/Wallis\",\"UTC\"],\"value\":0},\"keywords\":\"AVideo, videos, live, movies\"}","CustomizeAdvanced","CustomizeAdvanced","1.0"),
(5,"e9a568e6-ef61-4dcc-aad0-0109e9be8e36","active","2021-03-26 21:38:39","2021-03-26 21:38:39","{\"skin\":\"avideo\",\"playbackRates\":\"[0.5, 1, 1.5, 2]\",\"playerCustomDataSetup\":\"\",\"showSocialShareOnEmbed\":true,\"showLoopButton\":true,\"showLogo\":false,\"showShareSocial\":true,\"showLogoOnEmbed\":false,\"showLogoAdjustScale\":\"0.4\",\"showLogoAdjustLeft\":\"-74px\",\"showLogoAdjustTop\":\"-22px;\",\"disableEmbedTopInfo\":false,\"contextMenuDisableEmbedOnly\":false,\"contextMenuLoop\":true,\"contextMenuCopyVideoURL\":true,\"contextMenuCopyVideoURLCurrentTime\":true,\"contextMenuCopyEmbedCode\":true,\"contextMenuShare\":true,\"playerFullHeight\":false}","PlayerSkins","PlayerSkins","1.1"),
(6,"Permissions-5ee8405eaaa16","active","2021-03-26 21:38:39","2021-03-26 21:38:39","{}","Permissions","Permissions","1.0");


DROP TABLE IF EXISTS `sites`;

CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `secret` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `subscribes`;

CREATE TABLE `subscribes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `status` enum('a','i') NOT NULL DEFAULT 'a',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '1' COMMENT 'subscribes to user channel',
  `notify` tinyint(1) NOT NULL DEFAULT '1',
  `subscriber_users_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_subscribes_users1_idx` (`users_id`),
  KEY `fk_subscribes_users2_idx` (`subscriber_users_id`),
  CONSTRAINT `fk_subscribes_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_subscribes_users2` FOREIGN KEY (`subscriber_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(45) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL,
  `password` varchar(145) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('a','i') NOT NULL DEFAULT 'a',
  `photoURL` varchar(255) DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `recoverPass` varchar(255) DEFAULT NULL,
  `backgroundURL` varchar(255) DEFAULT NULL,
  `canStream` tinyint(1) DEFAULT NULL,
  `canUpload` tinyint(1) DEFAULT NULL,
  `canCreateMeet` tinyint(1) DEFAULT NULL,
  `canViewChart` tinyint(1) NOT NULL DEFAULT '0',
  `about` text,
  `channelName` varchar(45) DEFAULT NULL,
  `emailVerified` tinyint(1) NOT NULL DEFAULT '0',
  `analyticsCode` varchar(45) DEFAULT NULL,
  `externalOptions` text,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `zip_code` varchar(45) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `donationLink` varchar(225) DEFAULT NULL,
  `extra_info` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_UNIQUE` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES (1,"admin",NULL,"martinezmbithi@gmail.com","3dc0c26f3ebf52dc86d42d50b8d16e5a","2021-03-26 21:38:38","2021-03-26 21:38:38",1,"a",NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);


DROP TABLE IF EXISTS `users_blob`;

CREATE TABLE `users_blob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blob` longblob,
  `users_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_users_document_image_users1_idx` (`users_id`),
  CONSTRAINT `fk_users_document_image_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `users_extra_info`;

CREATE TABLE `users_extra_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_name` varchar(45) NOT NULL,
  `field_type` varchar(45) NOT NULL,
  `field_options` text,
  `field_default_value` varchar(45) DEFAULT NULL,
  `parameters` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `users_groups`;

CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `users_has_users_groups`;

CREATE TABLE `users_has_users_groups` (
  `users_id` int(11) NOT NULL,
  `users_groups_id` int(11) NOT NULL,
  PRIMARY KEY (`users_id`,`users_groups_id`),
  UNIQUE KEY `index_user_groups_unique` (`users_groups_id`,`users_id`),
  KEY `fk_users_has_users_groups_users_groups1_idx` (`users_groups_id`),
  KEY `fk_users_has_users_groups_users1_idx` (`users_id`),
  CONSTRAINT `fk_users_has_users_groups_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_users_has_users_groups_users_groups1` FOREIGN KEY (`users_groups_id`) REFERENCES `users_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `videos`;

CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(190) NOT NULL,
  `clean_title` varchar(190) NOT NULL,
  `description` text,
  `views_count` int(11) NOT NULL DEFAULT '0',
  `views_count_25` int(11) DEFAULT '0',
  `views_count_50` int(11) DEFAULT '0',
  `views_count_75` int(11) DEFAULT '0',
  `views_count_100` int(11) DEFAULT '0',
  `status` enum('a','k','i','e','x','d','xmp4','xwebm','xmp3','xogg','ximg','u','p','t') NOT NULL DEFAULT 'e' COMMENT 'a = active\nk = active and encoding\ni = inactive\ne = encoding\nx = encoding error\nd = downloading\nu = Unlisted\np = private\nxmp4 = encoding mp4 error \nxwebm = encoding webm error \nxmp3 = encoding mp3 error \nxogg = encoding ogg error \nximg = get image error\nt = Transfering',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `users_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `duration` varchar(15) NOT NULL,
  `type` enum('audio','video','embed','linkVideo','linkAudio','torrent','pdf','image','gallery','article','serie','zip') NOT NULL DEFAULT 'video',
  `videoDownloadedLink` varchar(255) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '1',
  `rotation` smallint(6) DEFAULT '0',
  `zoom` float DEFAULT '1',
  `youtubeId` varchar(45) DEFAULT NULL,
  `videoLink` varchar(255) DEFAULT NULL,
  `next_videos_id` int(11) DEFAULT NULL,
  `isSuggested` int(1) NOT NULL DEFAULT '0',
  `trailer1` varchar(255) DEFAULT NULL,
  `trailer2` varchar(255) DEFAULT NULL,
  `trailer3` varchar(255) DEFAULT NULL,
  `rate` float(4,2) DEFAULT NULL,
  `can_download` tinyint(1) DEFAULT NULL,
  `can_share` tinyint(1) DEFAULT NULL,
  `rrating` varchar(45) DEFAULT NULL,
  `externalOptions` text,
  `only_for_paid` tinyint(1) DEFAULT NULL,
  `serie_playlists_id` int(11) DEFAULT NULL,
  `sites_id` int(11) DEFAULT NULL,
  `video_password` varchar(45) DEFAULT NULL,
  `encoderURL` varchar(255) DEFAULT NULL,
  `filepath` varchar(255) DEFAULT NULL,
  `filesize` bigint(19) unsigned DEFAULT '0',
  `live_transmitions_history_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clean_title_UNIQUE` (`clean_title`),
  KEY `fk_videos_users_idx` (`users_id`),
  KEY `fk_videos_categories1_idx` (`categories_id`),
  KEY `index5` (`order`),
  KEY `fk_videos_videos1_idx` (`next_videos_id`),
  KEY `fk_videos_sites1_idx` (`sites_id`),
  KEY `clean_title_INDEX` (`clean_title`),
  KEY `video_filename_INDEX` (`filename`),
  KEY `video_status_idx` (`status`),
  KEY `video_type_idx` (`type`),
  KEY `fk_videos_live_transmitions_history1_idx` (`live_transmitions_history_id`),
  KEY `fk_videos_playlists1` (`serie_playlists_id`),
  KEY `videos_status_index` (`status`),
  KEY `is_suggested_index` (`isSuggested`),
  KEY `views_count_index` (`views_count`),
  KEY `filename_index` (`filename`),
  FULLTEXT KEY `index17vname` (`title`),
  FULLTEXT KEY `index18vdesc` (`description`),
  CONSTRAINT `fk_videos_categories1` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_videos_playlists1` FOREIGN KEY (`serie_playlists_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_videos_sites1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_videos_users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_videos_videos1` FOREIGN KEY (`next_videos_id`) REFERENCES `videos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `videos_group_view`;

CREATE TABLE `videos_group_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_groups_id` int(11) NOT NULL,
  `videos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_videos_group_view_users_groups1_idx` (`users_groups_id`),
  KEY `fk_videos_group_view_videos1_idx` (`videos_id`),
  CONSTRAINT `fk_videos_group_view_users_groups1` FOREIGN KEY (`users_groups_id`) REFERENCES `users_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_videos_group_view_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `videos_metadata`;

CREATE TABLE `videos_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `videos_id` int(11) NOT NULL,
  `resolution` varchar(12) NOT NULL,
  `format` varchar(12) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `videos_id` (`videos_id`,`resolution`,`format`,`stream_id`,`name`),
  KEY `fk_videos_metadata_videos1_idx` (`videos_id`),
  CONSTRAINT `fk_videos_metadata_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `videos_statistics`;

CREATE TABLE `videos_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `when` datetime NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `videos_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `lastVideoTime` int(11) DEFAULT NULL,
  `session_id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_videos_statistics_users1_idx` (`users_id`),
  KEY `fk_videos_statistics_videos1_idx` (`videos_id`),
  KEY `when_statisci` (`when`),
  KEY `session_id_statistics` (`session_id`),
  CONSTRAINT `fk_videos_statistics_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_videos_statistics_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



SET foreign_key_checks = 1;
